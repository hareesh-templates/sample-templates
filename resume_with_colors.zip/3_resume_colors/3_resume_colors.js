var active = document.getElementById("active");

function changeColor(color) {
    document.getElementById("body").style.background = color;
    document.getElementById("main_heading").style.color = color;
    document.getElementById("profile").style.color = color;
    document.getElementById("personal_details").style.color = color;
    document.getElementById("contact_details").style.color = color;
    document.getElementById("color_picker").style.color = color;
    document.getElementById("icon-envelope").style.color = color;
    document.getElementById("icon-phone").style.color = color;
    document.getElementById("icon-linkedin").style.color = color;
    document.getElementById("icon-facebook").style.color = color;
    document.getElementById("icon-twitter").style.color = color;
    document.getElementById("icon-instagram").style.color = color;
    document.getElementById("work_exp").style.color = color;
    document.getElementById("work_exp1").style.color = color;
    document.getElementById("work_exp2").style.color = color;
    document.getElementById("education_qualification").style.color = color;
    document.getElementById("matric").style.color = color;
    document.getElementById("under_graduation").style.color = color;
    document.getElementById("graduation").style.color = color;    
}

function MediumSeaGreen() {
    changeColor('MediumSeaGreen');
}			
function Tomato() {
    changeColor('Tomato');
}			
function SlateBlue() {
    changeColor('SlateBlue');
}			
function Orange() {
    changeColor('Orange');
}		
function DodgerBlue() {
    changeColor('DodgerBlue');
}		
function Violet() {
    changeColor('Violet');
}		
