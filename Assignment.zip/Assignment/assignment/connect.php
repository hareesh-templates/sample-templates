<?php  

define("HOST", "localhost");
define("USER", "root");
define("PASSWORD", "");
define("DBNAME", "company");
$conn = mysqli_connect(HOST,USER,PASSWORD,DBNAME);

?>