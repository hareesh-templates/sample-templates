
<!doctype html>
<?php 
	session_start();
    ob_start();
if(!isset($_SESSION["login_name"])){
		//echo "you are not logged in";
	return false;
	}
		
?>
<html>
		<head>
		<meta charset="utf-8">
		<title>Admin booking</title>
		<link rel="icon" href="images/favicon.ico" type="image/x-icon"/>
		<link rel="stylesheet" href="css/style.css">
		<link rel="stylesheet" type="text/css" href="slick/slick.css">
		<link rel="stylesheet" type="text/css" href="slick/slick-theme.css">
		<script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
		<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
		<link rel="stylesheet" href="css/style.css">
		<link rel="stylesheet" href="css/animate.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.theme.min.css">
		<script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
		<style>
.d{
	text-align: center;
	font-size: 15px;
	font-family: 'eurostileregular';
}
.img{
	width: 100%;
	height: auto;
}
.i {
	width: 70%;
	height: auto;
	margin-top: 30px;
}
.container {
	margin: 0px;
	padding: 0px;
	margin-left: 20px;
}
.body {
	overflow-x: hidden;
}
.h {
	text-align: center;
	margin-top: 50px;
	font-family: 'eurostileregular';
	color: #D82531;
	font-weight: 900;
}
.td {
	background-color: gray;
	border: 1px solid black;
}
.btn {
	color : white !important;
	background: burlywood;
}
center {
	background-color: #E3E1E1;
	margin-left: 21px;
	margin-right: 21px;
	margin-bottom: 20px;
	margin-top: 20px;
}
</style>                                                                                                                                    
		</head>

		<body>
			
        <?php require("connect.php");
	include("admin_header.php");
	?>
			<?php 
	if(!isset($_SESSION["login_name"])){
		echo "you are not logged in";
	}
		else{
			echo "Welcome ".$_SESSION["login_name"];
		}
			?>
        <br>
        <br>
        <?php 
	
		 $query = "select buy_now.id,user.firstname,user.phonenumber,buy_now.order_date from buy_now inner join user on buy_now.customer_id = user.id"; 
	 $result1=mysqli_query($conn,$query);
		//$count=mysqli_num_rows($result1);
		
	?>
		 <?php $y="" ; while($result= mysqli_fetch_array($result1))
		{
	$y++;
	?>
 
		
<table  class="table table-striped">
	<tr><tr>
	<th>Id</th>
	<th>Customer Name</th>
	<th>Phone Number</th>
	<th>Order Date</th>
	</tr>
	<tr>
	<td ><?php echo $result['id']; ?></td>
	<td><?php echo $result['firstname']; ?></td>
	<td><?php echo $result['phonenumber']; ?></td>
	<td><?php echo $result['order_date']; ?></td></tr>
	
	<tr>
	<th>Img</th>
	<th>Name</th>
	<th>Type</th> 
	<th>Price</th></tr>
	<?php $id= 1;
	 
	 $query_products = "select  order_products.order_id, products.Name,products.Type, products.Price,products.img from order_products 
inner join products on order_products.product_id = products.product_id 
where order_products.order_id =".$result['id'];
	
	 $result2=mysqli_query($conn,$query_products);
	
	while($result3 = mysqli_fetch_array($result2)) { 
		
		$img = "product/".$result3['img']; ?>
	<tr><td><img src= "<?php  echo $img ?>" width="25%"></td>
	<td><?php echo $result3['Name']; ?></td>
	<td><?php echo $result3['Type']; ?></td>
	<td>RS.<?php echo $result3 ['Price']; ?></td></tr>
	<?php $id++; 

}

} ?>
	</tr>
	</table>

		<?php 
	include("footer.php"); ?>
</body>
</html>