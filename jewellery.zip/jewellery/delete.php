<?php 
	session_start();
    ob_start();

	 ?>
	<?php
	if(isset($_REQUEST['id']))
	{
		require("connect.php");
		$user_id=$_SESSION['id'];
		$id=$_REQUEST['id'];
		echo $delete=mysqli_query($conn,"delete from cart where customer_id='$user_id' and product_id='$id' limit 1");
		if($delete)
		{
		//echo "Successfully delete";
			header("location:customer_cart.php");
		}
	}

?>

