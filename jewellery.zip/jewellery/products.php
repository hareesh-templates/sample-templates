<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Products</title>
	<link rel="icon" href="images/favicon.ico" type="image/x-icon"/>
<link rel="stylesheet" href="css/pro.css">
<link rel="stylesheet" type="text/css" href="slick/slick.css">
<link rel="stylesheet" type="text/css" href="slick/slick-theme.css">
<script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">

<link rel="stylesheet" href="css/animate.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.theme.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.js"></script>
              <script>
              new WOW().init();
              </script>
	<style>
	.active{
		text-decoration: none;
		color:#c29958;
	}
</style>
	<style>
body {font-family: Arial, Helvetica, sans-serif;}


.modal {
  display: none; 
  position: fixed; 
  z-index: 9999; 
  padding-top: 100px; 
  left: 0;
  top: 0;
  width: 100%; 
  height: 100%; 
  overflow: auto; 
  background-color: rgb(0,0,0); 
  background-color: rgba(0,0,0,0.4); 
}


.modal-content {
  background-color: #fefefe;
  margin: auto;
  padding: 17px 20px 3px;
  border: 1px solid #888;
  width: 24%;
  text-align: center;
  position: absolute;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
}


.close {
  color: #aaaaaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
	right: 19px;
position: absolute;
}

.close:hover,
.close:focus {
  color: #000;
  text-decoration: none;
  cursor: pointer;
}
		.color{
			color: #c29958;
		}
		.color:hover{
			text-decoration: none;
		
		}
</style>
</head>

<body>
	
	<?php
		$page='shop';
		include("header.php");
	?>
	
	
	<div class="container-fluid">
	<div class="box">
	<img src="images/productsbg.jpg" width="100%">
	</div>
	
	<div class="container toma">
	<div class="para  bg-white hide-this">
	<h2>Our Most Popular Diamond Collection </h2>
	<p>For those with a special occasion on the horizon, you’ll be sure to find a timeless pair of earrings at Forevermark. Explore our most popular earring designs, available in a whole range of styles and precious metals. From a classic pair of diamond studs to modern three stone earrings, halo stud earrings and elegant drop earrings, you’ll be sure to find the perfect style. Treasure them for years to come with our diamond care guide and keep your favourite earrings shining forever.</p>
	</div>
	</div>
	</div>
		
		<div class="cate">
		<div class="container-fluid cat">
	<div class="row">
	<div class="col-sm-12 text-center">
	<div class="row">
	<div class="col-lg-2 col-md-4 categories" id="showall">
	All
		</div>
		
		<div class="col-lg-2 col-md-4 categories showSingle" target="1">
		Rings
		</div>
		
		<div class="col-lg-2 col-md-4 categories showSingle" target="3">
		Bracelets
		</div>
		
		
		
		<div class="col-lg-2 col-md-4 categories showSingle" target="2">
		Earrings
		</div>
		<div class="col-lg-2 col-md-4 categories showSingle" target="4">
		Necklaces
		</div>
		<div class="col-lg-2 col-md-4 categories showSingle" target="5">
		Anklets
		</div>
		
		
		</div>
		</div>
	</div>
	</div>
	</div>
	<div id="div1" class="targetDiv">
	<div class="container-fluid">
		<div class="title"><b>Rings</b></div>
		<div class="jewel">
		<div class="row">
			<div class="col-md-4">
			<div>
			<img src="images/ring1.jpg" width="100%">
			
			<div class="icn">
						<i class="far fa-heart"></i>
						<br>
						<i class="fas fa-sync-alt"></i>
						<br>
						<i class="fas fa-search"></i>
					</div>
				<div class="top1">
				<div class="new">New</div>
				<div class="per2">
					<div class="per">10%</div>
					</div>
					</div>
					<div class="buttn">
					<button  class="btn butn1" id="myBtn">Add To Cart</button>
					</div>
					
		</div>
				<div class="diamond"><b>Perfect Diamond Jewelry</b></div>
				
			
			</div>
			<div class="col-md-4">
			<div>
				<img src="images/ring2.jpg" width="100%">
				<div class="icn">
						<i class="far fa-heart"></i>
						<br>
						<i class="fas fa-sync-alt"></i>
						<br>
						<i class="fas fa-search"></i>
					</div>
				<div class="top1">
				<div class="new">New</div>
				<div class="per2">
					<div class="per">10%</div>
					</div>
					</div>
					<div class="buttn">
					<button  class="btn butn1">Add To Cart</button>
					</div>
					</div>
				<div class="diamond"><b> Diamond Exclusive Ornament</b></div>
			</div>
			<div class="col-md-4">
			<div>
				<img src="images/ring3.jpg" width="100%">
				<div class="icn">
						<i class="far fa-heart"></i>
						<br>
						<i class="fas fa-sync-alt"></i>
						<br>
						<i class="fas fa-search"></i>
					</div>
				<div class="top1">
				<div class="new">New</div>
				<div class="per2">
					<div class="per">10%</div>
					</div>
					</div>
					<div class="buttn">
					<button  class="btn butn1">Add To Cart</button>
					</div>
					</div>
				<div class="diamond"><b>Handmade Diamond Jewelry</b></div>
			</div>
		</div>
			</div>
			
			<div class="row">
			<div class="col-md-4">
			<div class="icn">
						<i class="far fa-heart"></i>
						<br>
						<i class="fas fa-sync-alt"></i>
						<br>
						<i class="fas fa-search"></i>
					</div>
			<div>
				<img src="images/ring5.jpg" width="100%">
				<div class="icn">
						<i class="far fa-heart"></i>
						<br>
						<i class="fas fa-sync-alt"></i>
						<br>
						<i class="fas fa-search"></i>
					</div>
				<div class="top1">
				<div class="new">New</div>
				<div class="per2">
					<div class="per">10%</div>
					</div>
					</div>
					<div class="buttn">
					<button  class="btn butn1">Add To Cart</button>

					</div>
					</div>
				<div class="diamond"><b>Perfect Wedding Ring</b></div>
			</div>
			<div class="col-md-4">
			<div>
				<img src="images/ring6.jpg" width="100%">
				<div class="icn">
						<i class="far fa-heart"></i>
						<br>
						<i class="fas fa-sync-alt"></i>
						<br>
						<i class="fas fa-search"></i>
					</div>
				<div class="top1">
				<div class="new">New</div>
				<div class="per2">
					<div class="per">10%</div>
					</div>
					</div>
					<div class="buttn">
					<button  class="btn butn1">Add To Cart</button>
					</div>
					</div>
				<div class="diamond"><b>Exclusive Diamond Jewelry</b></div>
			</div>
			<div class="col-md-4">
			<div>
				<img src="images/ring7.jpg" width="100%">
				<div class="icn">
						<i class="far fa-heart"></i>
						<br>
						<i class="fas fa-sync-alt"></i>
						<br>
						<i class="fas fa-search"></i>
					</div>
				<div class="top1">
				<div class="new">New</div>
				<div class="per2">
					<div class="per">10%</div>
					</div>
					</div>
					<div class="buttn">
					<button  class="btn butn1">Add To Cart</button>
					</div>
					</div>
				<div class="diamond"><b>Pink Emerald Diamond Jewelry</b></div>
			</div>
			</div>
	</div>
		</div>
		<div id="div2" class="targetDiv">
			<div class="container-fluid">
		<div class="title"><b>Earrings</b></div>
		<div class="jewel">
		<div class="row">
			<div class="col-md-4">
			
				<img src="images/ear1.jpg" width="100%">
				<div class="icn">
						<i class="far fa-heart"></i>
						<br>
						<i class="fas fa-sync-alt"></i>
						<br>
						<i class="fas fa-search"></i>
					</div>
				<div class="top1">
				<div class="new">New</div>
				<div class="per2">
					<div class="per">10%</div>
					</div>
					</div>
					<div class="buttn">
					<button  class="btn butn1">Add To Cart</button>
					</div>
				<div class="diamond"><b>Circlet Drop Earrings</b></div>
				</div>
		
			<div class="col-md-4">
				<img src="images/ear2.jpg" width="100%">
				<div class="icn">
						<i class="far fa-heart"></i>
						<br>
						<i class="fas fa-sync-alt"></i>
						<br>
						<i class="fas fa-search"></i>
					</div>
				<div class="top1">
				<div class="new">New</div>
				<div class="per2">
					<div class="per">10%</div>
					</div>
					</div>
					<div class="buttn">
					<button  class="btn butn1">Add To Cart</button>
					</div>
				<div class="diamond"><b> Halo Tassels Earrings </b></div>
			</div>
			<div class="col-md-4">
				<img src="images/ear3.jpg" width="100%">
				<div class="icn">
						<i class="far fa-heart"></i>
						<br>
						<i class="fas fa-sync-alt"></i>
						<br>
						<i class="fas fa-search"></i>
					</div>
				<div class="top1">
				<div class="new">New</div>
				<div class="per2">
					<div class="per">10%</div>
					</div>
					</div>
					<div class="buttn">
					<button  class="btn butn1">Add To Cart</button>
					</div>
				<div class="diamond"><b>Handmade Diamond Jewelry</b></div>
			</div>
		</div>
			</div>
			
			<div class="row">
			<div class="col-md-4">
				<img src="images/ear4.jpg" width="100%">
				<div class="icn">
						<i class="far fa-heart"></i>
						<br>
						<i class="fas fa-sync-alt"></i>
						<br>
						<i class="fas fa-search"></i>
					</div>
				<div class="top1">
				<div class="new">New</div>
				<div class="per2">
					<div class="per">10%</div>
					</div>
					</div>
					<div class="buttn">
					<button  class="btn butn1">Add To Cart</button>
					</div>
				<div class="diamond"><b>Forever Stud Earrings</b></div>
			</div>
			<div class="col-md-4">
				<img src="images/ear5.jpg" width="100%">
				<div class="icn">
						<i class="far fa-heart"></i>
						<br>
						<i class="fas fa-sync-alt"></i>
						<br>
						<i class="fas fa-search"></i>
					</div>
				<div class="top1">
				<div class="new">New</div>
				<div class="per2">
					<div class="per">10%</div>
					</div>
					</div>
					<div class="buttn">
					<button  class="btn butn1">Add To Cart</button>
					</div>
				<div class="diamond"><b>Short Drop Diamond Earrings</b></div>
			</div>
			<div class="col-md-4">
				<img src="images/ear6.jpg" width="100%">
				<div class="icn">
						<i class="far fa-heart"></i>
						<br>
						<i class="fas fa-sync-alt"></i>
						<br>
						<i class="fas fa-search"></i>
					</div>
				<div class="top1">
				<div class="new">New</div>
				<div class="per2">
					<div class="per">10%</div>
					</div>
					</div>
					<div class="buttn">
					<button  class="btn butn1">Add To Cart</button>
					</div>
				<div class="diamond"><b> Multi-Metal Crossover Earrings</b></div>
			</div>
			</div>
			</div>
	</div>
			<div id="div3" class="targetDiv">
			<div class="container-fluid">
		<div class="title"><b>Bracelets</b></div>
		<div class="jewel">
		<div class="row">
			<div class="col-md-4">
				<img src="images/brace1.jpg" width="100%">
				<div class="icn">
						<i class="far fa-heart"></i>
						<br>
						<i class="fas fa-sync-alt"></i>
						<br>
						<i class="fas fa-search"></i>
					</div>
				<div class="top1">
				<div class="new">New</div>
				<div class="per2">
					<div class="per">10%</div>
					</div>
					</div>
					<div class="buttn">
					<button  class="btn butn1">Add To Cart</button>
					</div>
				<div class="diamond"><b>Coster Diamond Jewellery</b></div>
			</div>
			<div class="col-md-4">
				<img src="images/brace2.jpg" width="100%">
				<div class="icn">
						<i class="far fa-heart"></i>
						<br>
						<i class="fas fa-sync-alt"></i>
						<br>
						<i class="fas fa-search"></i>
					</div>
				<div class="top1">
				<div class="new">New</div>
				<div class="per2">
					<div class="per">10%</div>
					</div>
					</div>
					<div class="buttn">
					<button  class="btn butn1">Add To Cart</button>
					</div>
				<div class="diamond"><b> Fashion Gone Rogue</b></div>
			</div>
			<div class="col-md-4">
				<img src="images/brace3.jpg" width="100%">
				<div class="icn">
						<i class="far fa-heart"></i>
						<br>
						<i class="fas fa-sync-alt"></i>
						<br>
						<i class="fas fa-search"></i>
					</div>
				<div class="top1">
				<div class="new">New</div>
				<div class="per2">
					<div class="per">10%</div>
					</div>
					</div>
					<div class="buttn">
					<button  class="btn butn1">Add To Cart</button>
					</div>
				<div class="diamond"><b>Multiline Diamond Jewelry</b></div>
			</div>
		</div>
			
			
			<div class="row">
			<div class="col-md-4">
				<img src="images/brace4.jpg" width="100%">
				<div class="icn">
						<i class="far fa-heart"></i>
						<br>
						<i class="fas fa-sync-alt"></i>
						<br>
						<i class="fas fa-search"></i>
					</div>
				<div class="top1">
				<div class="new">New</div>
				<div class="per2">
					<div class="per">10%</div>
					</div>
					</div>
					<div class="buttn">
					<button  class="btn butn1">Add To Cart</button>
					</div>
				<div class="diamond"><b>Casual wear Diamonds</b></div>
			</div>
			<div class="col-md-4">
				<img src="images/brace5.jpg" width="100%">
				<div class="icn">
						<i class="far fa-heart"></i>
						<br>
						<i class="fas fa-sync-alt"></i>
						<br>
						<i class="fas fa-search"></i>
					</div>
				<div class="top1">
				<div class="new">New</div>
				<div class="per2">
					<div class="per">10%</div>
					</div>
					</div>
					<div class="buttn">
					<button  class="btn butn1">Add To Cart</button>
					</div>
				<div class="diamond"><b>Exclusive Diamond Bracelet</b></div>
			</div>
			<div class="col-md-4">
				<img src="images/brace6.jpg" width="100%">
				<div class="icn">
						<i class="far fa-heart"></i>
						<br>
						<i class="fas fa-sync-alt"></i>
						<br>
						<i class="fas fa-search"></i>
					</div>
				<div class="top1">
				<div class="new">New</div>
				<div class="per2">
					<div class="per">10%</div>
					</div>
					</div>
					<div class="buttn">
					<button  class="btn butn1">Add To Cart</button>
					</div>
				<div class="diamond"><b>Coster Bangle Jewelry</b></div>
			</div>
			</div>
			</div>
				</div>
				</div>
	<div id="div4" class="targetDiv">
			<div class="container-fluid">
		<div class="title"><b>Necklaces</b></div>
		<div class="jewel">
		<div class="row">
			<div class="col-md-4">
			
				<img src="images/dia1.jpg" width="100%">
				<div class="icn">
						<i class="far fa-heart"></i>
						<br>
						<i class="fas fa-sync-alt"></i>
						<br>
						<i class="fas fa-search"></i>
					</div>
				<div class="top1">
				<div class="new">New</div>
				<div class="per2">
					<div class="per">10%</div>
					</div>
					</div>
					<div class="buttn">
					<button  class="btn butn1">Add To Cart</button>
					</div>
				<div class="diamond"><b>Carat Diamond Necklace</b></div>
				</div>
		
			<div class="col-md-4">
				<img src="images/dia2.jpg" width="100%">
				<div class="icn">
						<i class="far fa-heart"></i>
						<br>
						<i class="fas fa-sync-alt"></i>
						<br>
						<i class="fas fa-search"></i>
					</div>
				<div class="top1">
				<div class="new">New</div>
				<div class="per2">
					<div class="per">10%</div>
					</div>
					</div>
					<div class="buttn">
					<button  class="btn butn1">Add To Cart</button>
					</div>
				<div class="diamond"><b> Floret White Necklace</b></div>
			</div>
			<div class="col-md-4">
				<img src="images/dia3.jpg" width="100%">
				<div class="icn">
						<i class="far fa-heart"></i>
						<br>
						<i class="fas fa-sync-alt"></i>
						<br>
						<i class="fas fa-search"></i>
					</div>
				<div class="top1">
				<div class="new">New</div>
				<div class="per2">
					<div class="per">10%</div>
					</div>
					</div>
					<div class="buttn">
					<button  class="btn butn1">Add To Cart</button>
					</div>
				<div class="diamond"><b>Emerald Diamond Necklace</b></div>
			</div>
		</div>
			</div>
			
			<div class="row">
			<div class="col-md-4">
				<img src="images/dia4.jpg" width="100%">
				<div class="icn">
						<i class="far fa-heart"></i>
						<br>
						<i class="fas fa-sync-alt"></i>
						<br>
						<i class="fas fa-search"></i>
					</div>
				<div class="top1">
				<div class="new">New</div>
				<div class="per2">
					<div class="per">10%</div>
					</div>
					</div>
					<div class="buttn">
					<button  class="btn butn1">Add To Cart</button>
					</div>
				<div class="diamond"><b>Splendour Diamond Necklace</b></div>
			</div>
			<div class="col-md-4">
				<img src="images/dia5.jpg" width="100%">
				<div class="icn">
						<i class="far fa-heart"></i>
						<br>
						<i class="fas fa-sync-alt"></i>
						<br>
						<i class="fas fa-search"></i>
					</div>
				<div class="top1">
				<div class="new">New</div>
				<div class="per2">
					<div class="per">10%</div>
					</div>
					</div>
					<div class="buttn">
					<button  class="btn butn1">Add To Cart</button>
					</div>
				<div class="diamond"><b>Enticing Diamond Necklace</b></div>
			</div>
			<div class="col-md-4">
				<img src="images/dia6.jpg" width="100%">
				<div class="icn">
						<i class="far fa-heart"></i>
						<br>
						<i class="fas fa-sync-alt"></i>
						<br>
						<i class="fas fa-search"></i>
					</div>
				<div class="top1">
				<div class="new">New</div>
				<div class="per2">
					<div class="per">10%</div>
					</div>
					</div>
					<div class="buttn">
					<button  class="btn butn1">Add To Cart</button>
					</div>
				<div class="diamond"><b>Lorelei Diamond Necklace</b></div>
			</div>
			</div>
			</div>
	</div>
	
	<div id="div5" class="targetDiv">
			<div class="container-fluid">
		<div class="title"><b>Anklets</b></div>
		<div class="jewel">
		<div class="row">
			<div class="col-md-4">
			
				<img src="images/ank1.jpg" width="100%">
				<div class="icn">
						<i class="far fa-heart"></i>
						<br>
						<i class="fas fa-sync-alt"></i>
						<br>
						<i class="fas fa-search"></i>
					</div>
				<div class="top1">
				<div class="new">New</div>
				<div class="per2">
					<div class="per">10%</div>
					</div>
					</div>
					<div class="buttn">
					<button  class="btn butn1">Add To Cart</button>
					</div>
				<div class="diamond"><b>Circlet Anklet</b></div>
				</div>
		
			<div class="col-md-4">
				<img src="images/ank2.jpg" width="100%">
				<div class="icn">
						<i class="far fa-heart"></i>
						<br>
						<i class="fas fa-sync-alt"></i>
						<br>
						<i class="fas fa-search"></i>
					</div>
				<div class="top1">
				<div class="new">New</div>
				<div class="per2">
					<div class="per">10%</div>
					</div>
					</div>
					<div class="buttn">
					<button  class="btn butn1">Add To Cart</button>
					</div>
				<div class="diamond"><b> Halo Tassels Anklet </b></div>
			</div>
			<div class="col-md-4">
				<img src="images/ank3.jpg" width="100%">
				<div class="icn">
						<i class="far fa-heart"></i>
						<br>
						<i class="fas fa-sync-alt"></i>
						<br>
						<i class="fas fa-search"></i>
					</div>
				<div class="top1">
				<div class="new">New</div>
				<div class="per2">
					<div class="per">10%</div>
					</div>
					</div>
					<div class="buttn">
					<button  class="btn butn1">Add To Cart</button>
					</div>
				<div class="diamond"><b>Bell Anklet</b></div>
			</div>
		</div>
			</div>
			
			<div class="row">
			<div class="col-md-4">
				<img src="images/ank4.jpg" width="100%">
				<div class="icn">
						<i class="far fa-heart"></i>
						<br>
						<i class="fas fa-sync-alt"></i>
						<br>
						<i class="fas fa-search"></i>
					</div>
				<div class="top1">
				<div class="new">New</div>
				<div class="per2">
					<div class="per">10%</div>
					</div>
					</div>
					<div class="buttn">
					<button class="btn butn1">Add To Cart</button>
					</div>
				<div class="diamond"><b>Forever Anklet</b></div>
			</div>
			<div class="col-md-4">
				<img src="images/ank5.jpg" width="100%">
				<div class="icn">
						<i class="far fa-heart"></i>
						<br>
						<i class="fas fa-sync-alt"></i>
						<br>
						<i class="fas fa-search"></i>
					</div>
				<div class="top1">
				<div class="new">New</div>
				<div class="per2">
					<div class="per">10%</div>
					</div>
					</div>
					<div class="buttn">
					<button  class="btn butn1">Add To Cart</button>
					</div>
				<div class="diamond"><b>Short Drop Anklet</b></div>
			</div>
			<div class="col-md-4">
				<img src="images/ank6.jpg" width="100%">
				<div class="icn">
						<i class="far fa-heart"></i>
						<br>
						<i class="fas fa-sync-alt"></i>
						<br>
						<i class="fas fa-search"></i>
					</div>
				<div class="top1">
				<div class="new">New</div>
				<div class="per2">
					<div class="per">10%</div>
					</div>
					</div>
					<div class="buttn">
					<button  class="btn butn1">Add To Cart</button>
					</div>
				<div class="diamond"><b> Multi Crossover Anklet</b></div>
			</div>
			</div>
			</div>
	</div>
	<div class="top">
		<a href="#arrow">
			<i class="fas fa-chevron-up"></i>
		</a>
	</div>
	
	
	
	
	
	
<script>
jQuery(function(){
         jQuery('#showall').click(function(){
               jQuery('.targetDiv').show();
        });
        jQuery('.showSingle').click(function(){
              jQuery('.targetDiv').hide();
              jQuery('#div'+$(this).attr('target')).show();
        });
		
		
});
</script>
	
	<div id="myModal" class="modal">

  <div class="modal-content">
    <span class="close">&times;</span>
    <p>Please <br> <a href="registration.php" class="color">Register</a> / <a href="login.php" class="color">Login</a></p>
  </div>

</div>

<script>

//var modal = document.getElementById("myModal");


//var btn = document.getElementById("myBtn");


//var span = document.getElementsByClassName("close")[0];


//btn.onclick = function() {
  //modal.style.display = "block";
//}
	
	$("button").click(function(){
		$("#myModal").show();
	})
	
	$(".close").click(function(){
		$("#myModal").hide();
	})

//span.onclick = function() {
  //modal.style.display = "none";
//}

window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
</script>
	
	<script type="text/javascript" src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js"></script>
	<script src="slick/slick.min.js" type="text/javascript" charset="utf-8"></script>

		<?php include("footer.php") ?>	
</body>
</html>
	
	
	
	
	
	
				
				
			
