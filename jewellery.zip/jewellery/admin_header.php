<!doctype html>

<style>
	.active1{
		text-decoration: none;
		color:#c29958 !important;
	}
</style>
<div class="container">
	<div class="row">
	<div class="col-sm-12">
			<nav class="navbar navbar-expand-lg">
  <a class="navbar-brand" href="#"><img src="images/logo.png"></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <i class="fas fa-bars" style="color:#c29958 "></i>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      
      <li class="nav-item">
        <a class="nav-link <?php if($page=='productenrolling'){echo 'active1';}?>" href="productenrolling.php">Product<span style="color:white">_</span>Entry</a>
      </li>
      <li class="nav-item">
        <a class="nav-link <?php if($page=='cart'){echo 'active1';}?>" href="admin_cart.php">Cart</a>
      </li>
      <li class="nav-item">
        <a class="nav-link <?php if($page=='shop'){echo 'active1';}?>" href="admin_shop.php">Shop</a>
      </li>
      <li class="nav-item">
        <a class="nav-link <?php if($page=='booking'){echo 'active1';}?>" href="admin_booking.php">Booking</a>
      </li>
		<li class="nav-item">
        <a class="nav-link <?php if($page=='booking'){echo 'active1';}?>" href="logout.php">Logout</a>
      </li>
     </ul>
	  
	   <!--a class="nav-link" href="registration.php">Register</a>/<a class="nav-link" href="login.php">Login </a-->
   	
 </div>
</nav>
	</div>
		</div>
	</div>