<?php
require("connect.php");
if($_POST)
{
	$email = $_POST['email'];
	$query = "insert into subscribe(email) values ('$email')";
	$result = $conn->query($query) or die($conn->error.__LINE__);
	if($query)
	{
		echo "<span>subscribed successfully</span>";
	}
	else{
		echo "Not subscribed";
	}

		}

?>