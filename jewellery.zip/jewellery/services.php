
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Services</title>
	<link rel="icon" href="images/favicon.ico" type="image/x-icon"/>
<link rel="stylesheet" href="css/services.css">
<link rel="stylesheet" type="text/css" href="slick/slick.css">
<link rel="stylesheet" type="text/css" href="slick/slick-theme.css">
<script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">

<link rel="stylesheet" href="css/animate.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.theme.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.js"></script>
              <script>
              new WOW().init();
              </script>
	<style>
	.active{
		text-decoration: none;
		color:#c29958;
	}
</style>
</head>

<body>
	

	<?php
		$page='services';
		include("header.php");
	?>
	<div class="container">
	<div class="heading"><b>DIAMOND SERVICES PROCESS</b></div>
		</div>
	
	<div class="container">
		
		
			<div class="process_list">
				<ul>
					<li>
			<img src="images/ser1.jpg" width="100%">
			<b>Receiving</b>
						</li>
			
			<li>
				<img src="images/ser2.jpg" width="100%">
				<b>Sorting and Tagging</b>
			</li>
					
			<li>
				<img src="images/ser3.jpg" width="100%">
				<b>High Resolution 360 degrees professional video of the item</b>
			</li>
					<li>
		<img src="images/ser4.jpg" width="100%">
						<b>Preparation for testing</b>
						</li>
					<li>
				<img src="images/ser5.jpg" width="100%">
						<b>Testing Process</b>
						</li>
					<li>
				<img src="images/ser7.jpg" width="100%">
						<b>Jewelry Testing Process </b>
						</li>
					<li>
				<img src="images/ser8.jpg" width="100%">
						<b>Results </b>
						</li>
					<li>
				<img src="images/ser9.jpg" width="100%">
						<b> Corano Card containing results, details and item video. </b>
						</li>
					
				
				</ul>
				</div>
			</div>
	<script type="text/javascript" src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js"></script>
	<script src="slick/slick.min.js" type="text/javascript" charset="utf-8"></script>
	<?php include("footer.php") ?>
	</body>
</html>
	
	
