
<!doctype html>
<?php 
	session_start();
    ob_start();
if(!isset($_SESSION["login_name"])){
		//echo "you are not logged in";
	return false;
	}
		//else{
			//echo "Welcome ".$_SESSION["login_name"];
		//}
?>
<html><head>
<meta charset="utf-8">
<title>shop</title>
	<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" type="text/css" href="slick/slick.css">
<link rel="stylesheet" type="text/css" href="slick/slick-theme.css">
<script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/animate.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.theme.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
          
             <script>
	$(document).ready(function(){
		$("button").click(function(e){
			//e.preventDefault();
			var button = $(this);
			var url = button.attr("name");
			
			jQuery.ajax({
				type: "POST",
				url: button.attr("name"),
				//data:form.serialize(),
				
				success:function(responsedata){
					$("#cart").show();
					$("#cart").html(responsedata);
				}
				
				
			});
		});
	});
</script>
      
	
	<style>
	.d{text-align: center;
	   font-size: 15px;
	font-family: 'eurostileregular';}
	.img{width:100%;height:auto;}
	.i{width:70%;height:auto;margin-top:30px; }
	.container{margin:0px;padding:0px;margin-left: 20px;}
	.body{overflow-x: hidden;}
	.h{text-align: center;margin-top: 50px;font-family: 'eurostileregular';color:#D82531;font-weight: 900;}
	.td{background-color: gray !important;border:1px solid black;}
	.btn{color :white !important;background:#c29958;}
	center{background-color:#E3E1E1;margin-left: 21px; margin-right:21px;margin-bottom:20px;margin-top: 20px; }
		a{
			color:#fff;
		}
	
	
	
	
	
		
		</style>
</head>

<body>
	 
	<?php require("connect.php");// here include database filent
	$result = mysqli_query($conn,"select * from products");
	
	
	include("header_u.php");
	
	
	 ?><br>
	<?php 
	if(!isset($_SESSION["login_name"])){
		echo "you are not logged in";
	}
		else{
			echo "Welcome ".$_SESSION["login_name"];
		}
	$user_id=$_SESSION['id'];
	$result1=mysqli_query($conn,"select *from cart where customer_Id='".$user_id."'");
	$count=mysqli_num_rows($result1);
	?>
	<div id="carouselExampleIndicators" class="carousel slide container-fluid" data-ride="carousel">
 
	</div>
	<div class="container"><br>
	
		<a href="customer_cart.php"><button class="btn btn-outline-success my-2 my-sm-0 fas fa-cart-plus" type="submit" style="float:right"><span id="cart"> <?php echo $count?> </span></button></a>
		
	<div class="container"><br>
	<!--span id="cart"> </span-->
	<form id="shop" method="post">
<?php
 $rows = $result->num_rows;    // Find total rows returned by database
 if($rows > 0) {
 $cols = 3;    // Define number of columns
 $counter = 1;     // Counter used to identify if we need to start or end a row
 $nbsp = $cols - ($rows % $cols);    // Calculate the number of blank columns
 
 echo '<table width="100%" align="center" cellpadding="4" cellspacing="2" >';
 while ($row = $result->fetch_array()) {
 if(($counter % $cols) == 1) {    // Check if it's new row
 echo '<tr>'; 
 }
                   //$img = "product/".$row['img'];
	
 echo '<div class="zb" ><td><center><img class="i" src="product/'.$row['img'].'" alt="'.$row['Name'].'" /><center><h5 class="d">'.$row['Name'].' </h5><div><h5 class="d">'.$row['Type'].'</h5></div><div><h5 class="d">RS'.$row['Price'].'</h5></div><div class="d"><button id="button" type="button" name="cart.php?id='.$row['product_id'].'">Add to Cart</button></div><br></td></div>';
 if(($counter % $cols) == 0) { // If it's last column in each row then counter remainder will be zero
 echo '</tr>'; 
 }
 $counter++;    // Increase the counter
 }
 $result->free();
 if($nbsp > 0) { // Add unused column in last row
 for ($i = 0; $i < $nbsp; $i++) { 
 echo '<td>&nbsp;</td>'; 
 }
 echo '</tr><br>';
 }
                echo '</table><br>';
 }
	
?>
	</form>	
	</div> 
		
		<script type="text/javascript" src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js"></script>
	<script src="slick/slick.min.js" type="text/javascript" charset="utf-8"></script>

	

<?php include("footer.php") ?>
	<button onclick="topFunction()" id="myBtn" title="Go to top"><i class="fas fa-angle-double-up"></i></button>
<script>
// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    document.getElementById("myBtn").style.display = "block";
  } else {
    document.getElementById("myBtn").style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}
</script>
</body>
</html>