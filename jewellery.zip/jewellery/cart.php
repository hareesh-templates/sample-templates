<?php
session_start();
    ob_start();

$user_id=$_SESSION['id'];

if(isset($_REQUEST['id']))
{
 require("connect.php");
 $id=$_REQUEST['id'];  
		$query="select * from products where product_id='".$id."'";
 $select = mysqli_query($conn,$query);
 $result=mysqli_fetch_array($select);
}
$name=$result["Name"];
$type=$result["Type"];
$price=$result["Price"];
$img=$result["img"];

$date=date("Y/m/d");

$query1="INSERT INTO `cart`( `product_Id`, `customer_Id`, `order_date`,  `Name`, `img`, `Type`, `price`) VALUES ('".$id."','".$user_id."','".$date."','".$name."','".$img."','".$type."','".$price."')";
$insert = mysqli_query($conn,$query1);

$user_id=$_SESSION['id'];
	$result1=mysqli_query($conn,"select *from cart where customer_Id='".$user_id."'");
	$count=mysqli_num_rows($result1);
if($insert && $count){
	//header("location:shop.php");
	echo " ".$count;
}

?>  