<?php 
require("connect.php"); 
if($_POST['submit']){
 $firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$phonenumber = $_POST['phonenumber'];
$email = $_POST['email'];
$password = $_POST['password'];
$address=$_POST['address'];

}
$type=1;
 
 echo $query="insert into user(firstname,lastname,phonenumber,email,password,address,type) values('".$firstname."','".$lastname."', '".$phonenumber."','".$email."',  '".$password."','".$address."','".$type."')";
$creatTable = mysqli_query($conn, $query);

if($creatTable){
//echo "success" ;
	header("location:index.php");
}
else{
echo "not success";}
?>