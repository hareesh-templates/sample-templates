<?php 
	session_start();
    ob_start();
?>
<?php
if(isset($_REQUEST['id']))
	{
		require("connect.php");
		$user_id=$_SESSION['id'];
		$id=$_REQUEST['id'];
}
		 $select=mysqli_query($conn,"select * from cart where customer_id='$user_id' and product_id='$id' ");
		 $row=mysqli_fetch_array($select);
		 $id=$row['product_id'];
		 $user_id=$row['customer_id'];
		 $date=date("Y/m/d");
		 $name=$row['Name'];
		 $img=$row['img'];
		 $type=$row['Type'];
		 $price=$row['Price'];
		 $oid=$row['order_id'];
	   echo $query1="INSERT INTO `booking`( `order_id`,`product_id`, `customer_id`, `order_date`,  `Name`, `img`, `Type`, `Price`) VALUES ('".$oid."','".$id."','".$user_id."','".$date."','".$name."','".$img."','".$type."','".$price."')";

     $insert = mysqli_query($conn,$query1);
	 if($insert){
	

		echo $delete=mysqli_query($conn,"delete from cart where customer_id='$user_id' and product_id='$id' limit 1");
		if($delete)
		{
		//echo "Successfully delete";
			header("location:customer_cart.php");
		}
}

?> 

