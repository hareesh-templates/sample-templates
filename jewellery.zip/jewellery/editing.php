<?php
require("connect.php");
if(isset($_POST['update_form'])){
	$id= $_POST['id'];
	$name= $_POST['name'];
	$type= $_POST['type'];
	$price=$_POST['price'];
	
	$updateData = mysqli_query($conn,"update products set Name='".$name."',Type='".$type."',Price='".$price."'where product_id='".$id."'") ;   
	if($updateData)
	{
		//echo "Successfully Update Data into products Table";
		header("location:admin_shop.php");
	}
}
?>