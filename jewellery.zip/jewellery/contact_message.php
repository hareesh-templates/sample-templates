<?php
require("connect.php");
if(isset($_POST['submit']))
{
	$name = $_POST['name'];
	$phonenumber = $_POST['phonenumber'];
	$email = $_POST['email'];
	$subject = $_POST['subject'];
	$message = $_POST['message'];
	$query = "insert into contact(name,phonenumber,email,subject,message) values ('$name','$phonenumber','$email','$subject','$message')";
	$result = $conn->query($query) or die($conn->error.__LINE__);
	if($query)
	{
		echo "Message successfully";
	}
	else{
		echo "Not successfuli";
	}

		}

?>