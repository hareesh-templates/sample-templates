<?php  

define("HOST", "localhost");
define("USER", "root");
define("PASSWORD", "");
define("DBNAME", "corano");
$conn = mysqli_connect(HOST,USER,PASSWORD,DBNAME);

?>