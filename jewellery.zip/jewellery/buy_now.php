<?php
session_start();
    ob_start();

$values = $_POST;

$products = array();

foreach ($values as $key => $value) {
    $products[] = $key;
}
 
 

$user_id=$_SESSION['id'];
	 
 require("connect.php");
 
 
$date=date("d");
$month=date("m");
$year=date("Y");
$date1 = $date."/".$month."/".$year;

 $query1="INSERT INTO `buy_now`(`customer_id`, `order_date`) VALUES ( '".$user_id."','".$date1."')";

if ($conn->query($query1) === TRUE) {
    $last_id = $conn->insert_id;  
	
	for($i=0;$i< count($products); $i++){
 $query2="INSERT INTO `order_products`(`order_id`, `product_id`   ) VALUES ( '". $last_id."','".$products[$i]."')";
		
if ($conn->query($query2) === TRUE) {
	$query3="delete from cart where customer_Id='".$user_id."' ";
 $delete = mysqli_query($conn,$query3);
 
}
}
	if($delete){
	 echo "<br><br>Successfully Booked!";
	//header("location:customer_cart.php");
 }	
}
?>
