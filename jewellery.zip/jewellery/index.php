
<?php 
	$page='home';
	
	?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Jewellery</title>
<link rel="icon" href="images/favicon.ico" type="image/x-icon"/>
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" type="text/css" href="slick/slick.css">
<link rel="stylesheet" type="text/css" href="slick/slick-theme.css">
<script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">

<link rel="stylesheet" href="css/animate.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.theme.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.js"></script>
              <script>
              new WOW().init();
              </script>
	<style>
	.active{
		text-decoration: none;
		color:#c29958 !important;
	}
		.color{
			color:#c29958;
		}
		.color:hover{
			text-decoration: none;
			color: black;
		}
</style>
</head>

<body>





	<?php 
	include("header.php");
	
	?>
	
	
	
	
	
	<div class="bd-example">
  <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
   
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img src="images/image1.png" class="d-block w-100" alt="...">
        <div class="top-right">
        <div class="wow fadeInDown">Family Jewellery<br>Collection
        </div>
		<div class="grace">Designer Jewellery Necklaces-Bracelets-Earings.
		</div>
		<button  class="btn butn1">Read More</button>
		</div>
      </div>
      <div class="carousel-item">
        <img src="images/image2.png" class="d-block w-100" alt="...">
        <div class="top-left">
        <div class="wow fadeInDown">Diamond Jewellery<br> Collection</div>
		<div class="grace">Shukra Yogam  &amp; Silver Power Silver Saving Schemes.
		</div>
		<button  class="btn butn1">Read More</button>
		</div>
      </div>
      <div class="carousel-item">
        <img src="images/image3.png" class="d-block w-100" alt="...">
        <div class="top-right">
        <div class="wow fadeInDown">Grace Designer<br>Jewellery</div>
		<div class="grace">Rings,Occasion Pieces, Pandora &amp; More.
		</div>
		<button  class="btn butn1">Read More</button>
		</div>
      </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
      <button onclick="next(1)" class="buttons next btn"><i class="fas fa-chevron-left"></i></button>
      <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
      <button onclick="next(-1)" class="buttons prev btn"><i class="fas fa-chevron-right"></i></button>
      <span class="sr-only">Next</span>
    </a>
    
    
  </div>
</div>
	
	
	
	<div class="container spa">
		<div class="row">
			<div class="col-sm-3">
			<img src="images/flight.png" style="float:left;padding-right: 16px;">
			<ul type="none">
			<li>Free Shipping</li>
			<li>Free Shipping on all orders</li>

			</ul>
		</div> 

		
		<div class="col-sm-3">
		<img src="images/support.png" style="float:left;padding-right: 16px;">
		<ul type="none">
			<li>Support 24/7</li>
			<li>Support 24 hours a day</li>
			</ul>
		</div>
		
		
		<div class="col-sm-3">
		<img src="images/money.png" style="float:left;padding-right: 16px;">
		<ul type="none">
			<li>Money Return</li>
			<li>30 days for free return</li>
			</ul>
		</div>

		<div class="col-sm-3">
		<img src="images/payment.png" style="float:left;padding-right: 16px;">
		<ul type="none">
			<li>100% Payment Secure</li>
			<li>We ensure payment secure</li>
			</ul>
		</div>
		</div>
	</div>
	
	<div class="container">
	<div class="row">
		<div class="col-sm-6">
		<div class="cont">
			<img src="images/rings.png" width="100%" class="image">
			<div class="overlay"><a href="products.php" class="color">Shop Now</a></div>
			</div>
			</div>
		<div class="col-sm-6">
		<div class="cont">
			<img src="images/earring.png" width="100%" class="image">
			<div class="overlay"><a href="products.php" class="color">Shop Now</a></div>
		</div>
	</div>
	</div>
	<br>
	
	<div class="row">
		<div class="col-sm-6">
		<div class="cont">
			<img src="images/necklaces.png" width="100%" class="image">
			<div class="overlay"><a href="products.php" class="color">Shop Now</a></div>
		</div>
		</div>
	<div class="col-sm-6">
		<div class="cont">
			<img src="images/shoe.png" width="100%" class="image">
			<div class="overlay"><a href="products.php" class="color">Shop Now</a></div>
		</div>
		</div>
	</div>
	</div>
		
	
	
	
    
    <div class="test">
	<div class="container">
		<div class="title"><b>Latest Designs</b></div>
		<p class="sub-title">There are latest posts</p>
	</div>
	
	
	<div class="container">
		<section class="regular slider">
		
   <div class="mod6">
    <div class="slide">
		<a data-toggle="modal" data-target="#myModal6"> 
		<img src="images/blog1.jpg">
		 <center>
		 <div class="overlay1">
		 <div class="t"><b>Sparkler Stone</b></div>
		 
			 </div>
			 </center>
			 </a>
	   </div>
			</div>
	   
	   <div class="mod6">
    <div class="slide">
     <a data-toggle="modal" data-target="#myModal7">
		 <img src="images/blog2.jpg">
      <center>
      <div class="overlay1">
       <div class="t"><b>Green Emerald Wristlet</b></div>
     </div>
     </center>
     </a>
		   </div>
		   </div>
		   
		   <div class="mod6">
    <div class="slide">
     <a data-toggle="modal" data-target="#myModal8">
      <img src="images/blog3.jpg">
       <center>
       <div class="overlay1">
       <div class="t"><b>Cincture Diamond Neckalce</b></div>
      </div>
      </center>
      </a>
			   </div>
			   </div>
			   
			   <div class="mod6">
    <div class="slide">
     <a data-toggle="modal" data-target="#myModal9">
      <img src="images/blog4.jpg">
       <center>
       <div class="overlay1">
       <div class="t"><b>Arm Band</b></div>
      </div>
      </center>
      </a>
				   </div></div>
				   
				   <div class="mod6">
    <div class="slide">
     <a data-toggle="modal" data-target="#myModal10">
      <img src="images/blog5.jpg" >
       <center>
       <div class="overlay1">
       <div class="t"><b>Lavaliere Ice</b></div>
     </div>
				   </center>
				 </a>
					   </div>
					   </div>
					   
					   </section>
					   </div>
					   
				</div>	   
	
	
	
	

	
	
	
<div class="test1">
	<div class="container">
		<div class="title "><b>Testimonials</b></div>
		<p class="sub-title what">What they say</p>
	</div>
	

	



	<div class="container">
	<div class="row ">
		<div class="col-sm-6 offset-sm-3 text-center">
			<img src="images/test1.png" id="1" class="si">
			<img src="images/test2.png" id="2" class="si">
			<img src="images/test3.png" id="3" class="si">
			
		</div>
		</div>
		
		<div class="row s">
			<div id="a" class="text-center">Corano developed our website www.3coresystems.com ,we liked the way they showcased our website and I highly recommend them if you are looking for a tech as well as a creative genius.</div>
			
			
			<div id="b" style="display: none" class="text-center">Corano showcased our website with the new design for your creative and professional work for earlyappletree. We liked the way they showcased our website and I highly recommend them if you are looking for a tech as well as a creative genius.</div>
			
			<div id="c" style="display: none" class="text-center">Thanks for your creative and professional work for earlyappletree. Your designers have really impressed me with the new design and conveys what exactly we doing and i am so excited.</div>
			
		</div>
	</div>
	</div>
	
<?php include("footer.php") ?>
	
	<div class="top">
		<a href="#arrow">
			<i class="fas fa-chevron-up"></i>
		</a>
	</div>
	
	
<script>
	$(document).ready(function(){
		$("#1").click(function(){
			$("#a").css({display:"block"})
			$("#b").css({display:"none"})
			$("#c").css({display:"none"})
		})
		$("#2").click(function(){
			$("#b").css({display:"block"})
			$("#a").css({display:"none"})
			$("#c").css({display:"none"})
		})
		$("#3").click(function(){
			$("#c").css({display:"block"})
			$("#b").css({display:"none"})
			$("#a").css({display:"none"})
		})
	})
		
	</script>

	<script type="text/javascript" src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js"></script>
	<script src="slick/slick.min.js" type="text/javascript" charset="utf-8"></script>
 <script>
$(document).ready(function(){
    $("#testimonial-slider").owlCarousel({
        items:1,
        itemsDesktop:[1000,1],
        itemsDesktopSmall:[979,1],
        itemsTablet:[768,1],
        pagination:false,
        navigation:false,
        navigationText:["",""],
        slideSpeed:1000,
        autoPlay:true,
		
		controller:true
    });
});
</script>
	
<script>
$(".regular").slick({
	dots:false,
	infinite:true,
	centerMode:true,
	slidesToShow:3,
	slidesToScroll:1,
	autoplay:true,
	autoplaySpeed:2500
	});
	
</script>

</body>
</html>
