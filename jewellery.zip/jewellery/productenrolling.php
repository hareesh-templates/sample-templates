<?php 
	session_start();
    ob_start();?>
<!doctype html>


<html>
<head>
<meta charset="utf-8">
<title>product enrolling</title>
<link rel="icon" href="images/favicon.ico" type="image/x-icon"/>
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" type="text/css" href="slick/slick.css">
<link rel="stylesheet" type="text/css" href="slick/slick-theme.css">
<script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">

<link rel="stylesheet" href="css/animate.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.theme.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
              <script>
              new WOW().init();
              </script>
	<style>
	.active{
		text-decoration: none;
		color:#c29958 !important;
	}
</style>
</head>
	
	
	

	
	<style>

	#submit{
		    margin-left: 440px;
		    margin-top: 30px;
		    padding: 20px;
	}
	 .f{border: 2px solid white;margin-bottom:20px;}
      .h1{
		  color :white;
           background:#c29958;
            text-align:center
		}
    body{ background:;}
	#btn{
		color :white;       
	   background:#c29958;
		}
		.ze{
			margin-top:119px;
		}
		
		.overlay {
  height: 100%;
  width: 100%;
  display: none;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: rgb(0,0,0);
  background-color: rgba(0,0,0, 0.9);
}
.btn {
    background-color: #c29958 !important;
    color: white!important;
    border: burlywood!important;
}
#myBtn{
  display: none;
  position: fixed;
  bottom: 20px;
  right: 30px;
  z-index: 99;
  font-size: 36px;
  border: none;
  outline: none;
  color:#ECC179;
  background-color: transparent;
  cursor: pointer;
  padding: 15px;
  border-radius: 4px;
		}
		.overlay {
  height: 100%;
  width: 100%;
  display: none;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: rgb(0,0,0);
  background-color: rgba(0,0,0, 0.9);
}

.overlay-content {
  position: relative;
  top: 25%;
  width: 100%;
  text-align: center;
  margin-top: 30px;
}

.overlay a {
  padding: 8px;
  text-decoration: none;
  font-size: 36px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.overlay a:hover, .overlay a:focus {
  color: #f1f1f1;
}

.overlay .closebtn{
  position: absolute;
  top: 20px;
  right: 45px;
  font-size: 60px;
}
.12{
	color: #eee;
	margin-left:5px;
		} 
</style>
	<script>

$(document).ready(function(){
$("#submit").click(function()
 {
	
 var fname=$("#name").val();
  if (fname == "")
      {
	  $("#name_error").text("please enter First Name");
	   $("#name").focus();
	  return false;
      }
	
	
	
	var lname=$("#tname").val();
	if(lname == "")
		{
		$("#tname_error").text("please enter Temporary name");
		 $("#tname").focus();	
		return false;
		}
	
	
	var Email=$("#type").val();
	if(Email == "")
		{
		$("#type_error").text("please enter  Type");
		 $("#type").focus();	
		return false;
		}
	
		var pnumber=$("#price").val();
	if(pnumber == "")
		{
		$("#price_error").text("please enter Price");
		 $("#price").focus();	
		return false;
		}
	
});	
	
	$("#name").click(function(){
		$("#name_error").hide();
	});
	
	$("#tname").click(function(){
		$("#tname_error").hide();
	});
	$("#type").click(function(){
		$("#type_error").hide();
	});

	$("#price").click(function(){
		$("#price_error").hide();
	});
	$("#desc").click(function(){
		$("#desc_error").hide();
	});


});
			 
</script>
</head>

<body>
	
	
	
	<?php include("admin_header.php"); ?>
	<?php
if(!isset($_SESSION["login_name"])){
		//echo "you are not logged in";
	return false;
	}
		else{
			echo "Welcome ".$_SESSION["login_name"];
		}
?>
	<br><br>
<form  class="f" action="orderinfo.php" method="post"  enctype="multipart/form-data">
<div class="h1"><h1> Manage Products</h1></div>
	<br><br>
	<div class="container">
   <div class="row">
    <div class="col-sm-3">
    <label for="inputfname">Product Name</label> </div>
    <div class="col-sm-6">
      <input type="text" class="form-control" id="name" placeholder="Name" name="name">
      <span id="name_error" style="color: red;"></span>
    </div>
  </div><br>
  
  <div class="row">
    <div class="col-sm-3">
    <label for="inputEmail">Type of Ornament</label> </div>
    <div class="col-sm-6">
      <select name="type" class="form-control">
		  <option>Rings</option>
		  <option>Bracelets</option>
		  <option>Earrings</option>
		  <option>Necklaces</option>
		  <option>Anklets</option>
		</select>
    </div>
  </div><br>
	<div class="row">
   <div class="col-sm-3">
    <label for="inputPassword">Price</label></div>
    <div class="col-sm-6">
       <input type="text" class="form-control" id="Password" placeholder="Price" name="price">
      <span id="price_error"  style="color: red;"></span>
    </div>
		</div><br>
	
	<div class="row">
    <div class="col-sm-3">
    <label for="inputdesc">Product Image</label></div>
    <div class="col-sm-6">
       <input type="file"  name="file_name" required>
      
    </div>
	</div><br>
	 
	
 
<center><input id="btn" type="submit" value="Register Now" name="order"> 
</form>
</div>	
<?php include("footer.php")?> 	
	
</body>
</html>