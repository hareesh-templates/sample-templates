

	<?php
	session_start();
	include("connect.php");
	unset($_SESSION['login_name']);
	unset($_SESSION['emailid']);
	unset($_SESSION['type']);
	unset($_SESSION['id']);
	header("location:index.php");
	?>
	
