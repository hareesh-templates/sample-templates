<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Jewellery</title>
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" type="text/css" href="slick/slick.css">
<link rel="stylesheet" type="text/css" href="slick/slick-theme.css">
<script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">

<link rel="stylesheet" href="css/animate.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.theme.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.js"></script>
	
	
	
	<link rel="icon" type="image/png" href="./Login_v8/images/icons/favicon.ico"/>

	<link rel="stylesheet" type="text/css" href="./Login_v8/vendor/css-hamburgers/hamburgers.min.css">

	<link rel="stylesheet" type="text/css" href="./Login_v8/vendor/animsition/css/animsition.min.css">

	<link rel="stylesheet" type="text/css" href="./Login_v8/vendor/select2/select2.min.css">
	
	<link rel="stylesheet" type="text/css" href="./Login_v8/vendor/daterangepicker/daterangepicker.css">

	<link rel="stylesheet" type="text/css" href="./Login_v8/css/util.css">
	<link rel="stylesheet" type="text/css" href="./Login_v8/css/main.css">
              <script>
              new WOW().init();
              </script>
</head>
<style>
	.cat{
	background-color: #c29958;
	}
	
	
	span{
		color:red;
	}	
	.error{
		color:red;
	}
	.registration_form{
		position: absolute;
		top:50px;
		left:15%;
		width:70%;
		background-color:antiquewhite;
		padding:30px;
		border-radius: 20px;
		
	}
	
	.registration_form input{
		margin:10px;
	}
	h1{
		text-align:center;
		color:#000;
		margin:20px 0 60px 0;
	}
	.btn1{
		margin:5px;
	}
	</style>
	<script>
		
		function isNumber(evt){
		var charCode=evt.which;
			
		if(charCode>=48 && charCode <=57){
			return true;
		}
			else{
				return false;
			}
	}
		function fn_clear(){
			document.getElementById("fn_error").innerHTML=""
		}
		
		function ln_clear(){
			document.getElementById("ln_error").innerHTML=""
		}
		function pn_clear(){
			document.getElementById("pn_error").innerHTML=""
		}
		
		function em_clear(){
			document.getElementById("em_error").innerHTML=""
		}
		
	 function validation(){
var password1 = document.getElementById("pass1").value;
	var password2 = document.getElementById("pass2").value;

	if(password1==password2) 
{
	document.getElementById("pass_e").innerHTML="password matched";
return true;
}
if(password1!=password2)
{
	document.getElementById("pass_e").innerHTML="password not matched";
	return false;
}

		 fn = document.getElementById("fname").value;
		 ln = document.getElementById("lname").value;
		 pn = document.getElementById("pnumber").value;
		 em = document.getElementById("email").value;
		 
		 var fn_error=false;
		 var ln_error=false;
		 var pn_error=false;
		 var em_error=false;
		 
		 if(fn==""){
			 fn_error=true;
		 }
		 if(ln==""){
			 ln_error=true;
		 }
		 
		 if(pn==""){
			 pn_error=true;
		 }
		 if(em==""){
			 em_error=true;
		 }
		 if (fn_error==true)
			 {
				 document.getElementById("fn_error").innerHTML="Enter the first name";
			 }
		  if (ln_error==true)
			 {
				 document.getElementById("ln_error").innerHTML="Enter the last name";
			 }
		 if (pn_error==true)
			 {
				 document.getElementById("pn_error").innerHTML="Enter the Phone number";
				
			 }
		  if (em_error==true)
			 {
				 document.getElementById("em_error").innerHTML="Enter the Email ID";
			 }
			
		
		 if((fn_error==true)||(ln_error=true)||(pn_error=true)||(em_error==true)){
			 return false;
		 }
		
		
	 }

	 function len(){
		pn = document.getElementById("pnumber").value;
		if(pn.length<10){
		
		document.getElementById("pn_error").innerHTML="Number must be 10numbers";	
		
	}
	if(pn.length>10){
		
		document.getElementById("pn_error").innerHTML="Number must be 10numbers";
		return false;
		
	}

	 }
	</script>
</head>

<body>
	<?php include("header.php") ?>

	<!--form  action="validate.php" method="POST">
		
	<!--h1 class="cat">Login Form</h1>
	
	<!--div class="row">
			<div class="col-sm-6">	
				Email ID: <span>*</span><input type="email" id="email" name="email" class="form-control"  onKeypress="em_clear()"> <span id="em_error" class="error"></span>
			</div>
		

			<div class="col-sm-6">
			Password : <span>*</span><input type="password" name="password" class="form-control" id="pass1" onKeyUp="color()">
			</div>		
				
										
</div-->
		
		
		
		<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login1000">
				<span class="login100-form-title">
							LOGIN
				</span>
			
			<div class="wrap-login100">
				
				<form  action="validate.php" method="POST" class="login100-form validate-form p-l-55 p-r-55 p-t-178">

					<div class="wrap-input100 validate-input m-b-16" data-validate="Please enter username">
						<input class="input100" type="text"  name="email" placeholder="Email" required>
						<span class="focus-input100"></span>
					</div>

					<div class="wrap-input100 validate-input" data-validate = "Please enter password">
						<input class="input100" type="password" name="password" placeholder="Password" required>
						<span class="focus-input100"></span>
					</div>

					<div class="text-right p-t-13 p-b-23">
						<!--<span class="txt1">
							Forgot
						</span>

						<a href="#" class="txt2">
							Username / Password?
						</a>-->
					</div>

					<div class="container-login100-form-btn">
						
							<input type="submit" value="submit" name="submit" class="login100-form-btn" onClick="validation()">
						
					</div>

					<div class="flex-col-c p-t-60 p-b-40">
						<span class="txt1 p-b-9">
							Don’t have an account?
						</span>
						
						<a href="registration.php" class="txt3">
							Register
						</a>
					</div>
				</form>
			</div>
			</div>
		</div>
	</div>
<br>
			<!--<div class="row">
			<div class="col-sm-12 text-center">	
	<input type="submit" value="submit" name="submit" class="btn butn1" onClick="validation()"></div>
	</div>>
	
	</form-->	
   
	
	<br>
	<script src="./Login_v8/vendor/animsition/js/animsition.min.js"></script>

	<script src="./Login_v8/vendor/select2/select2.min.js"></script>

	<script src="./Login_v8/vendor/daterangepicker/moment.min.js"></script>
	<script src="./Login_v8/vendor/daterangepicker/moment.js"></script>

	<script src="./Login_v8/vendor/countdowntime/countdowntime.js"></script>

	<script src="js/main.js"></script>
	
	<script type="text/javascript" src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js"></script>
	<script src="slick/slick.min.js" type="text/javascript" charset="utf-8"></script>
	<?php include("footer.php") ?>
</body>
</html>