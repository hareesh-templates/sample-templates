
	<?php
require("connect.php");
	if(isset($_POST['order'])){
		 $name = $_POST['name'];
		 
		$type = $_POST['type'];
			$Price=$_POST["price"];
		$fileName = $_FILES['file_name']['name'];
		$fileTmp =$_FILES['file_name']['tmp_name'];
		
	
		$filePath='product/'.$fileName;}
		move_uploaded_file($fileTmp,$filePath);
		echo $query="INSERT INTO products( Name,Type,Price,img) VALUES ('".$name."','".$type."','".$Price."','".$fileName."')";
 $insert=mysqli_query($conn,$query);
 if($insert){
	 header("location:productenrolling.php");
 }

	?>
