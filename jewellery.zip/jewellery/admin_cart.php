

<!doctype html>
<?php 
	session_start();
    ob_start();
if(!isset($_SESSION["login_name"])){
		//echo "you are not logged in";
	return false;
	}
		//else{
			//echo "Welcome ".$_SESSION["login_name"];
		//}
?>
<html>
		<head>
		<meta charset="utf-8">
		<title>Admin Cart</title>
		<link rel="icon" href="images/favicon.ico" type="image/x-icon"/>
		<link rel="stylesheet" href="css/style.css">
		<link rel="stylesheet" type="text/css" href="slick/slick.css">
		<link rel="stylesheet" type="text/css" href="slick/slick-theme.css">
		<script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
		<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
		<link rel="stylesheet" href="css/style.css">
		<link rel="stylesheet" href="css/animate.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.theme.min.css">
		<script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
		<style>
.d {
	text-align: center;
	font-size: 15px;
	font-family: 'eurostileregular';
}
.img {
	width: 100%;
	height: auto;
}
.i {
	width: 70%;
	height: auto;
	margin-top: 30px;
}
.container {
	margin: 0px;
	padding: 0px;
	margin-left: 20px;
}
.body {
	overflow-x: hidden;
}
.h {
	text-align: center;
	margin-top: 50px;
	font-family: 'eurostileregular';
	color: #D82531;
	font-weight: 900;
}
.td {
	background-color: gray;
	border: 1px solid black;
}
.btn {
	color : white !important;
	background: burlywood;
}
center {
	background-color: #E3E1E1;
	margin-left: 21px;
	margin-right: 21px;
	margin-bottom: 20px;
	margin-top: 20px;
}
</style>
		</head>

		<body>
        <?php require("connect.php");
	include("admin_header.php");
	?>
			<?php 
	if(!isset($_SESSION["login_name"])){
		echo "you are not logged in";
	}
		else{
			echo "Welcome ".$_SESSION["login_name"];
		}
			?>
        <br>
        <br>
        <?php
	
	$result1=mysqli_query($conn,"select cart.order_id,cart.customer_id,cart.order_date,cart.Name,cart.Type,cart.Price,cart.img,user.firstname,user.phonenumber from cart inner join user where cart.customer_id=user.id");
	$count=mysqli_num_rows($result1);
	
	
		

 /*$rows = $result->num_rows;    // Find total rows returned by database
 if($rows > 0) {
 $cols = 3;    // Define number of columns
 $counter = 1;     // Counter used to identify if we need to start or end a row
 $nbsp = $cols - ($rows % $cols);    // Calculate the number of blank columns
 
 echo '<table width="100%" align="center" cellpadding="4" cellspacing="2" >';
 while ($row = $result->fetch_array()) {
 if(($counter % $cols) == 1) {    // Check if it's new row
 echo '<tr>'; 
 }
                   $img = "product/".$row['img'];
	 
	
 echo '<div class="zb" ><td><center><img class="i" src="product/'.$row['img'].'" alt="'.$row['Name'].'" /><center><h5 class="d">'.$row['Name'].' </h5><div><h5 class="d">'.$row['Type'].'</h5></div><div><h5 class="d">RS'.$row['Price'].'</h5></div><div><h5 class="d">Name-'.$row['firstname'].'</h5></div><div><h5 class="d">phonenumber-'.$row['phonenumber'].'</h5></div><div><h5 class="d">date-'.$row['order_date'].'</h5></div><br></td></div>';
	 
	
	 
	 
 if(($counter % $cols) == 0) { // If it's last column in each row then counter remainder will be zero
 echo '</tr>'; 
 }
 $counter++;    // Increase the counter
 }
 $result->free();
 if($nbsp > 0) { // Add unused column in last row
 for ($i = 0; $i < $nbsp; $i++) { 
 echo '<td>&nbsp;</td>'; 
 }
 echo '</tr><br>';
 }
                echo '</table><br>';
 }*/
	?>
	<table class="table table-striped">
	<tr>
		<th>id</th>
	<th>img</th>
	<th>Name</th>
	<th>Type</th>
	<th>Price</th>
	<th>Date</th>
	<th>Customer id</th>
	<th>Customer Name</th>
	<th>Phonenumber</th>
	</tr>
	<?php $y="" ; while($result = mysqli_fetch_array($result1 ))
{
	$y++;
	$img = "product/".$result['img'];
	?>
	<tr>
	<td><?php echo $result['order_id']; ?></td>	
	<td><img src=<?php echo $img ?> width="25%"></td>
	<td><?php echo $result['Name']; ?></td>
	<td><?php echo $result['Type']; ?></td>
	<td><?php echo $result['Price']; ?></td>
	<td><?php echo $result['order_date']; ?></td>
	<td><?php echo $result['customer_id']; ?></td>
	<td><?php echo $result['firstname']; ?></td>
		<td><?php echo $result['phonenumber']; ?></td>
	</tr>
	<?php } ?>
	</table>

        <?php 
	include("footer.php"); ?>
</body>
</html>