
	<?php
	if(isset($_REQUEST['id']))
	{
		require("connect.php");
		
		$id=$_REQUEST['id'];
		echo $delete=mysqli_query($conn,"delete from products where product_id='$id' limit 1");
		if($delete)
		{
		//echo "Successfully delete";
			header("location:admin_shop.php");
		}
	}

?>

