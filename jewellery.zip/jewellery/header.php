<style>
	.active1{
		text-decoration: none;
		color:#c29958 !important;
	}
	.space{
		position: relative;
	}
</style>
<div class="container">
	<div class="row">
	<div class="col-sm-12">
			<nav class="navbar navbar-expand-lg">
  <a class="navbar-brand" href="#"><img src="images/logo.png"></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <i class="fas fa-bars" style="color:#c29958 "></i>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item">
        <a class="nav-link <?php if($page=='home'){echo "active1";}?>" href="index.php" id="arrow">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link <?php if($page=='about'){echo 'active1';}?>" href="aboutus.php">About</a>
      </li>
      <li class="nav-item">
        <a class="nav-link <?php if($page=='shop'){echo 'active1';}?>" href="products.php">Shop</a>
      </li>
      <li class="nav-item">
        <a class="nav-link <?php if($page=='services'){echo 'active1';}?>" href="services.php">Services</a>
      </li>
      <li class="nav-item">
        <a class="nav-link <?php if($page=='contact'){echo 'active1';}?>" href="contact.php">Contact</a>
      </li>
     </ul>
	  
	   <a class="nav-link" href="registration.php">Register</a>/<a class="nav-link" href="login.php">Login </a>
	  <span class="space">
   	<input type="text" class="btn btn-light sear" placeholder="Search entire store here">
      <i class="fas fa-search searc"></i>
		  </span>
 </div>
</nav>
	</div>
		</div>
	</div>