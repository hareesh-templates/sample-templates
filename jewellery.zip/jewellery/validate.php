<?php 
require("connect.php"); 
session_start();
ob_start();

if($_POST['submit']){

 $email = $_POST['email'];

 $password = $_POST['password'];
}

$query= "select * from user WHERE email='".$email."' and password='".$password."'";
$result = $conn->query($query) or die ($conn->error.__LINE__);
$row = $result->fetch_array();
$count=$result->num_rows;
if($count==1){
$_SESSION['login_name'] =$row['firstname'];
	$_SESSION['emailid']=$row['email'];
	$_SESSION['type']=$row['type'];
	$_SESSION['id']=$row['id'];
	if($_SESSION['type']==1){
		header("location:shop.php");
	}
	if($_SESSION['type']==0){
		//echo "welcome admin";
		header("location:productenrolling.php");
	}
//header("location:session.php");
//echo "login sucessful";
}
else{
echo "wrong credentials";
}
?>