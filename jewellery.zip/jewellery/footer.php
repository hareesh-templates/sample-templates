<script>
	$(document).ready(function(){
		$("#subscribe").submit(function(e){
			e.preventDefault();
			var form=$(this);
			
			jQuery.ajax({
				type:"POST",
				url:"subscribe.php",
				data:form.serialize(),
				success:function(data){
					$("#subscribe")[0].reset();
					$("#sub").show();
					$("#sub").html(data);
				}
				
				
			});
		});
	});
</script>
<div class="foot backgro">
<div class="container  pad-bot">
<div class="row">
<div class="col-sm-12 col-md-3">
<img src="images/logo1.png">
<br>
<div>We are a team of designers and developers that create high quality wordpress,shopify,opencart.</div>	
</div>

<div class="col-sm-12 col-md-3 text-left">

	<div class=""><b>Contact Us</b>
	
	<div>
	<img src="images/phn.png" class="phone"><span class="text-hov">4710-4890 Breckinridge USA</span>
	</div>
	<div>
		<img src="images/mail.png" class="phone"><span class="text-hov">cordemo@yourdomain.com</span>
		</div>
		<div>
	
	<img src="images/ph.png" class="phone"><span class="text-hov">(012) 200 800 456 789-987</span>
		</div>
	</div>
</div>
<div class="col-sm-12 col-md-2">
	<div class="info"><b>Information</b>
			<br>
			About Us
			<br>
			Privet Policy
			<br>
			Contact Us
			<br>
			Delivery Information
			<br>
			Terms &nbsp; Conditions
			<br>
			Site Map
			</div>

	</div>
<div class="col-sm-4">
<div><b>Follow Us</b>
	<br>
	
		<i class="fab fa-facebook-f icons"></i>
		<i class="fab fa-twitter icons"></i>
		<i class="fab fa-instagram icons"></i>
		<i class="fab fa-youtube icons"></i>
			</div>
			</div>
	
		<br>
		
	
</div>
	
<div class="row">
		<div class="col-sm-6">
		
			<div><b>Signup for newsletter</b></div>
			
			
			<div class="border1 position-relative">
			<span id="sub" style="display: none;">
				
			</span>
			<form action="" id="subscribe" method="post">
				<input type="email" name="email" placeholder="Enter your email address" style="background-color :transparent;border: none"> 
				<input type="submit" class="subs" value="subscribe" name="submit">
				<!--button class="subs">Subscribe</button-->
				</form>
				
	</div>
		</div>
				
		
			
	<div class="col-sm-6 text-ri">
		<img src="images/visa.png">
		<img src="images/master.png">
		<img src="images/cir.png">
		<img src="images/discover.png">
		<img src="images/paypal.png">
		</div>	
		</div>
	</div>
	</div>
	