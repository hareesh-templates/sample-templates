<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>
<?php 
	echo 'welcome to PHP world'."<br>";
	?>
	<?='Short Cut Welcome to PHP world';?>
<body>
</body>
</html>