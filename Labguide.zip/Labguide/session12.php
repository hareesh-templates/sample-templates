<!doctype html>
<html>
	<title>oprators</title>
<head>
<meta charset="utf-8">
</head>

<body>
	<?php 
	define("DBNAME","my_db");
	define("HOST","localhost");
	define("USER","root");
	define("PASSWORD","");
	echo DBNAME."<br>";
	echo HOST."<br>";
	echo USER."<br>";
	echo PASSWORD."<br>";
	?>
</body>
</html>