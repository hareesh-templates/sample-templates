<!DOCTYPE html>
<html>
<head>
<title>file read only</html>
</head>
<body>
<?php
      $phpFile='phpfile.txt';
	  $fileFunction=fopen($phpFile,'r')or die('Cannot open file:$phpFile');
	  echo "<h2>Here display file data line by line read only.</h2><br>";
	  $addData=fwrite($fileFunction,"r+ read and write mode,places the pointer at begining of file.");
	  $fileFunction=fopen($phpFile,'r+')or die('Cannot open file:'.$phpFile);
	  while(!feof($fileFunction))
	  {
		  $displayFile=fgets($fileFunction);
		  echo $displayFile."<br>";
	  }
	  ?>