<!doctype html>
<html>
<body>
<?php
         if(isset($_COOKIE['student_name']))
             {
               echo "Student Name".$_COOKIE[$cookieName];
}
?>
</body>
</html>