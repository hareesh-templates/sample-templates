<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>file upload</title>
</head>

<body>
	<form action="fileupload.php" method="POST" enctype="multipart/form-data">
	<input type="file" name="file_name"/>
		<input type="submit"/>
		<?php
		     if(isset($_FILES['file_name']))
			 {
				 $fileName=$_FILES['file_name']['name'];
				 $fileSize=$_FILES['file_name']['size'];
				 $fileTmp=$_FILES['file_name']['tmp_name'];
				 $fileType=$_FILES['file_name']['type'];
				  $filePath='upload/'.$fileName;
				 if($fileSize<=1024)
				 {
					 echo 'File size should be less than or equal to 1 MB';
					  }
				 else{
					 move_uploaded_file($fileTmp,$filePath);
					 echo "Successfully uploaded";
				 }
			 
			 
			 }
		?>
	</form>
</body>
</html>