<!DOCTYPE html>
<html>
<title>Data type</title>
<head>
</head>
<body>
<?php
$boolean=true;
if($boolean)
{
echo "correct";
}
else
{
echo "wrong";
}
?>
</body>
</html>