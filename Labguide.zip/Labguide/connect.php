<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>connect</title>
</head>

<body>
	<?php
	     define("HOST","localhost");
	     define("USER","root");
	     define("PASSWORD","");
	     define("DBNAME","php");
	     $conn=mysqli_connect(HOST,USER,PASSWORD,DBNAME);
	     if($conn)
		 {
			 echo "database connected succeddfully!";
		 }
	else{
		echo "Unable to connected database!";
		exit();
	}
	?>
	</body>
</html>