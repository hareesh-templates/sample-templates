<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Array</title>
</head>

<body>
	<?php 
	$softLang=array("PHP","JAVA","NET","C#","C++");
	print_r($softLang);
	?>
</body>
</html>