<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
	<?php
	   $fruites="mango";
	   switch($fruites)
	   {
		   case "Apple":
			   echo "Apple Fruit";
			   break;
		   case "Orange":
			   echo "Orange Fruit";
			   break;
		   case "mango":
			   echo "Mango Fruit";
			   break;
		   default:
			   echo "no fruit available";
	   }
	?>
</body>
</html>