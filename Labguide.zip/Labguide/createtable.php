<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>createtable</title>
</head>

<body>
	<?php
	      require("connect.php");
	      $createTable=mysqli_query($conn,"Create table stundent(std_id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
		                                    first_name VARCHAR(50) NOT NULL,
											last_name VARCHAR(50) NOT NULL,
											age INT(2) NOT NULL,
											phone_num int(20) NULL)")or die("Unable to Create Table or Table already Exists");
	      if($createTable)
		  {
			  echo "Successfully Created Table";
		  }
	?>
</body>
</html>