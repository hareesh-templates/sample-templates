<?php require("connect.php");
     if(isset($_REQUEST['id']))
	 {
		 
		 $id=$_REQUEST['id']; 
		 $delete=mysqli_query($conn,"delete from student where std_id='$id'");
		 if($delete){
			 echo "Successfully Deleted";
		 }
		
		 
		 
	 }
?>