<!DOCTYPE html>
<html>
<head>
<title>write only</title>
</head>
<body>
<?php 
      $phpFile='phpfile.txt';
	  $fileFunction=fopen($phpFile,'a')or die('Cannot open file:'.$phpFile);
	  echo "<h2>Here display file data character by character write only.</h2><br>";
	  $addData=fwrite($fileFunction,"\n a write mode,appending the data at end of file.");
	  $fileFunction=fopen($phpFile,'a')or die('Cannot open file:'.$phpFile);
	  while(!feof($fileFunction))
	  {
		  $displayFile=fgets($fileFunction);
		  echo $displayFile."<br>";
	  }
	  Fclose($fileFunction);
	  ?>