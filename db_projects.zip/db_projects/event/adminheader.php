<div class="full">
	<div class="lg">
	<img src="images/lg3.jpg" alt="">
			<nav class="navbar navbar-expand-lg te">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto ml-auto">
      
	  <li class="nav-item">
        <a class="nav-link" href="wedadmin.php">WEDDINGS</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="partyadmin.php">PARTIES</a>
      </li>
    		
		<li class="nav-item">
        <a class="nav-link" href="contadmin.php">CONTACT US</a>
      </li>
		<li class="nav-item">
        <a class="nav-link" href="admin.php">SIGNIN</a>
      </li>
		<li class="nav-item">
        <a class="nav-link" href="logout.php">SIGN OUT</a>
      </li>
		
		 </li>
		
    </ul>
				
  </div>
</nav>
		</div>
				</div>