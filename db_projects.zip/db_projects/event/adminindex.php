<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>wedd</title>
	<link rel="stylesheet" href="CSS/event.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<link rel="stylesheet" href="animate.css">
 <script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.js"></script>
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
              <script>
              new WOW().init();
              </script>
</head>

<body>
	<?php include("adminheader.php") ?> 
	
	<div class="v">
		<video src="images/Royal+Wedding+-+KSA.mp4" width="100%" loop autoplay muted></video></div>
	
	<div class="container">
		<h3 class="he">LUXURY WEDDING PLANNERS & PARTY PRODUCERS</h3>
	</div>
	
	<div class="container">
		<div class="row con">
			<div class="offset-sm-1 col-sm-10">
				<div class="row">
    			<div class="col-sm-4">
					<div class="c">
       					<img src="images/s1.jpg" alt="Avatar" class="image1">
						<div class="overlay1">
    						<div class="text1">To achieve great things, two things are needed: a plan and not quite enough time.</div>
						</div>
					</div>
    			</div>
    			<div class="col-sm-4">
					<div class="c">
       					<img src="images/s2.jpg" alt="Avatar" class="image1">
						<div class="overlay1">
    						<div class="text1">Where there is love there is life.</div>
						</div>
  					</div>
    			</div>
    			<div class="col-sm-4">
					<div class="c">
      					<img src="images/s3.jpg" alt="Avatar" class="image1">
						<div class="overlay1">
    						<div class="text1">Education is the most powerful weapon which you can use to change the world.</div>
						</div>
  					</div>
    			</div>
  				</div>
			</div>
		</div>
	</div>
	
	<div class="container">
		<div class="row con">
			<div class="offset-sm-1 col-sm-10">
				<div class="row">
    			<div class="col-sm-4">
					<div class="c">
       					<img src="images/s4.jpg" alt="Avatar" class="image1">
						<div class="overlay1">
    						<div class="text1">Creativity takes courage</div>
						</div>
					</div>
    			</div>
    			<div class="col-sm-4">
					<div class="c">
       					<img src="images/s5.jpg" alt="Avatar" class="image1">
						<div class="overlay1">
    						<div class="text1">The map was just an accessory. She knew exactly where she was.</div>
						</div>
  					</div>
    			</div>
    			<div class="col-sm-4">
					<div class="c">
      					<img src="images/s6.jpg" alt="Avatar" class="image1">
						<div class="overlay1">
    						<div class="text1">The only security of all is in a free press.</div>
						</div>
  					</div>
    			</div>

  				</div>
			</div>
		</div>
	</div>
	
	<div class="container">
		<div class="row con">
			<div class="offset-sm-1 col-sm-10">
				<div class="row">
    			<div class="col-sm-4">
					<div class="c">
						<img src="images/s7.jpg" alt="Avatar" class="image1">
						<div class="overlay1">
    						<div class="text1">Entertainment and information work well together</div>
						</div>
					
						<!--<div class="overlay1">
    						<div class="text1">GALLERY</div>
						</div>-->
					</div>
    			</div>
    			<div class="col-sm-4">
					<div class="c">
       					<video src="images/Chicago Indian Muslim wedding highlights Sundus Asim.mp4" class="v" loop autoplay muted></video>
  					</div>
    			</div>
    			<div class="col-sm-4">
					<div class="c">
      					<img src="images/s8.jpg" alt="Avatar" class="image1">
						<div class="overlay1">
    						<div class="text1">It's very, very dangerous to lose contact with living nature.</div>
						</div>
  					</div>
    			</div>
  				</div>
			</div>
		</div></div>
	<!--<div class="container">-->
<div class="ad">
	<p><b>LENS OF THE PARTY PLANNERS -</b>follow us on <a href="www.google.com">Instagram</a> for peek inside our world of luxury weddings and celebrations...</p>
	</div><!--</div>-->
	
<!--	<div class="container">-->
	<div class="col-sm-12 co">
		<h6>Shananaz Luxury Wedding Planners,Party Planners & Event Designers</h6>
		<p>We plan elegant, stylish, glamorous and fun celebrations and are the Luxury Wedding Planners for savvy, sophisticated couples who demand first class service and a world-class event. From pop stars to princesses and from weddings in London and the UK to destination weddings in Europe and beyond, we strive to be the best at what we do (and several prestigious publications have been kind enough to state that we are!).</p>
<p>Our discerning, international client base includes some of the world's leading families for whom we create magical, immersive, world-class experiences. From weddings and birthday parties to bar mitzvahs, special anniversary celebrations and children's parties, every event we plan is unique.</p>
<p>Founder Shahanaz Shaik is an award winning, internationally acclaimed British luxury wedding planner, party planner and best-selling wedding author. She is frequently quoted in newspapers and magazines around the world, and regularly appears on television and radio in her capacity as a wedding expert.</p>


		
		</div>
	<!--</div>-->
	
	<?php include("footer.php") ?>
	

</body>
</html>
