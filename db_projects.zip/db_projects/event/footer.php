<footer>
	<div class="fo">
		<div class="container">
  <div class="row">
    <div class="col-sm-6">
      <p>Copyright @ ,All Rights Reserved</p>
    </div>
    <div class="col-sm-6">
     <a href="www.google.com"> <i class="fab fa-facebook-square"></i></a>
		<a href="www.google.com"> <i class="fab fa-instagram"></i></a>
		<a href="www.google.com"> <i class="fab fa-twitter-square"></i></a>

    </div>
  </div>
		</div>
		</div>
	</footer>