<?php 
require("connect.php"); 
if($_POST['submit']){
 $name = $_POST['Name'];
 $email = $_POST['EMail'];
 $address = $_POST['Address'];
 $religion = $_POST['religion'];
	 $telephone = $_POST['Telephone'];
	 $date = $_POST['Date'];
	$function = $_POST['function'];
	 $budjet = $_POST['budjet'];
	 $Comment = $_POST['Comment'];
	

}
 $query="insert into wedregister(name,address,email,religion,phonenumber,telephone,date,function,budjet,comment)
 values('".$Name."','".$Address."','".$EMail."','".$religion."','".$Telephone."','".$Date."','".$function."','".$budjet."','".$Comment."')";
$creatTable = mysqli_query($conn, $query);

if($creatTable){
echo "sucess" ;
}
else{
echo "not success";}
?>