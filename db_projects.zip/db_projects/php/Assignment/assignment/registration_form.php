<?php 
require("connect.php"); 
if($_POST['submit']){
 $name = $_POST['name'];
 $email = $_POST['email'];
 $phonenumber = $_POST['phonenumber'];
 $password = $_POST['password'];

}
 $query="insert into register(name,phonenumber,email,password)
 values('".$name."','".$phonenumber."','".$email."','".$password."')";
$creatTable = mysqli_query($conn, $query);

if($creatTable){
echo "sucess" ;
}
else{
echo "not success";}
?>