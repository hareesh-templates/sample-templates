<?php  

require("connect.php");
$creatTable = mysqli_query($conn, "CREATE TABLE registation(
Reg_id int(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
first_name varchar(20), 
last_name varchar(10),
email text(20), 
phone_number bigint(12),
password varchar(20)
 )") or die("unable to creat table");
if($creatTable){
	echo "sucessfully creat table";

}
else{
	echo "please try again";
}
?>