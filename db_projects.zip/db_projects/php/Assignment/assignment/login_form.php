<?php 
require("connect.php"); 
if($_POST['submit']){

 $email = $_POST['email'];

 $password = $_POST['password'];
}

$query= "select * from register WHERE email='".$email."' and password='".$password."'";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_array($result, MYSQLI_ASSOC);
$count=mysqli_num_rows($result);
if($count==1){
echo "login sucessfullt";
}
else{
echo "wrong creditials";
}
?>