<!DOCTYPE html>
<html>
<title>Assignment Operators</title>
<head>
</head>
<body>
<?php
$userName=" abc";
echo "Assign Variable :".$userName."<br>";
$password=" abc@123";
echo "Assign Variable :".$password."<br>";
$userName.=$password;
echo "String Concate assign variable: ".$userName;
?>
