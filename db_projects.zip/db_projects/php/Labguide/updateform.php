<?php require("connect.php");
     if(isset($_POST['editform']))
		 {
		 $first_name=$_POST['first_name'];
		 $last_name=$_POST['last_name'];
		 $age=$_POST['age'];
		 $phoneNumber=$_POST['phone_num'];
		 $updateData=mysqli_query($conn,"update student set first_name="shahanaz",last_name="shaik",age="23",phone_num="9384848399" where std_id=".$id"");
		 
		 if($updateData){
			 echo "Successfully updated data into student table";
		 }
		
		 }
?>