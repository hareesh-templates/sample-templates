<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
	<?php 
	   $string1="Welcome to strings";
	   $string2="Php World";
	   echo "String 1:".$string1."<br>";
	   echo "String 2:".$string2."<br>";
	   echo "Concate two strings:".$string1.'and'.$string2."<br><br>";
	   echo "Replace strings to Php World:".str_replace("strings",$string2,$string1)."<br><br>";
	   echo "Change all letters to uppercase:".strtoupper($string1)."<br><br>";
	   echo "Change all letters to lowercase:".strtolower($string1)."<br><br>";
	   echo "Change every word first letter to uppercase:".ucwords($string1)."<br><br>";
	   echo "Change first letter to capital:".ucfirst($string1)."<br><br>";
	   echo "length of string:".strlen($string1)."<br><br>";
	   echo "words count:".str_word_count($string1)."<br><br>";
	   echo "words count:".strpos($string1,"to")."<br><br>";
	   echo "Revers String:".strrev($string1)."<br><br>";
	   echo "Strings to Array:";
	   $stringToArray=explode(" ",$string1);
	   print_r($stringToArray);
	?>
       
	   
</body>
</html>