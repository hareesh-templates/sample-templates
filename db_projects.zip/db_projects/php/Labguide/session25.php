<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
	<?php
	 $class=array("student1_name"=>"Sai","student2_name"=>"Ram","student3_name"=>"Raju");
	 foreach($class as $key=>$value)
	 {
		 echo $key.'=>'.$value.'<br/>';
		 }
	echo "<br>";
	echo $class["student1_name"]."<br>";
	echo $class["student2_name"]."<br>";
	echo $class["student3_name"]."<br>";
	?>
</body>
</html>