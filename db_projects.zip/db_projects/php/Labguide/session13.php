<!doctype html>
<html>
	<title>Arithmatic Operators</title>
<head>
<meta charset="utf-8">
</head>

<body>
	<?php 
	$marks1=50;
	$marks2=80;
	
               $addMarks=$marks1+$marks2;
	$subMarks=$marks2-$marks1;
	$multipleMarks=$marks2*$marks1;
	$divideMarks=$marks2/$marks1;
	$percentage=$addMarks/200*100;
	$module=$marks2%$marks1;
              
               echo 'Sum Of Makrs:'.$addMarks.'<br>';
               echo 'Subtraction Of Marks:'.$subMarks.'<br>';
               echo 'Multiple Of Marks:'.$multipleMarks.'<br>';
               echo 'Division Of Marks:'.$divideMarks.'<br>';
               echo 'Percentage:'.$percentage.'<br>';
               echo 'Module Of Marks:'.$module.'<br>';
	?>
</body>
</html>