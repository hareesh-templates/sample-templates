<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
	<?php
	   function first_function_name()
	   {
		   echo "Without Parameters : Welcome to functions<br>";
	   }
	   function total_marks($m1,$m2,$m3)
	   {
		   $display=$m1+$m2+$m3;
		   echo "Function With Parameters:".$display."<br>";
	   }
	first_function_name();
	total_marks(100,200,300);
	total_marks(500,70,300);
	total_marks(700,50,300);
    ?>
	</body>
</html>