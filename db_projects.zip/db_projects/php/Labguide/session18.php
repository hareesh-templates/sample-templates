<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
	<?php 
	   $student1=50;
	   $student2=90;
	   $student3=100;
	     if($student1>$student2)
		 {
			 echo "String1 have heighst marks!";
		 }
	     else if($student1>$student3)
		 {
			 echo "Student2 have heighst marks!";
		 }
	else
	{
		echo "Student 3 have heighst marks!";
	}
	?>
</body>
</html>