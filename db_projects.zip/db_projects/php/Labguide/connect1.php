<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
	<form action="form1.php" method="post">
		First Name:<input type="text" name="firstname"/><br><br>
		Last Name:<input type="text" name="lastname"/><br><br>
		Email:<input type="text" name="email"/><br><br>
		Phone Number:<input type="text" name="phone_number"/><br>
		Age:<input type="text" name="age"/>
		<input name="submit_form" type="submit"></form>
	</body>
 		
	</form>
</body>
</html>