
			  <?php
	          if(isset($_POST['submit'])){
		echo "name:" .$_POST['name'].'<br>';
	    echo "email:". $_POST['email'].'<br>';
		echo "number:". $_POST['number'].'<br>';
				 
		echo "email:". $_POST['message'].'<br>';
				   echo "select:". $_POST['select'].'<br>';
			  }
	
	?>
	 