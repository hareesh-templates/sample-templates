<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>rename</title>
</head>

<body>
	<?php
	      require("connect.php");
	      $renameTable=mysqli_query($conn,"rename table studentNew to student");
	      if($renameTable)
		  {
			  echo "successfully Renamed Table";
		  }
	?>
</body>
</html>