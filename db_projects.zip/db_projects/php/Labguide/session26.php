<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
	<?php
	  $marks=array(array("Ram",50,60,80),array("daisy",50,40,40),array("orchaid",70,30,80));
	  print_r($marks);
	?>
</body>
</html>