<!DOCTYPE html>
<html>
<head>
<title>write only</title>
</head>
<body>
<?php 
      $phpFile='phpfile.txt';
	  $fileFunction=fopen($phpFile,'r+')or die('Cannot open file:'.$phpFile);
	  echo "<h2>Here display file data character by character write only.</h2><br>";
	  $addData=fwrite($fileFunction,"Here display file data line by line , read and write.mode");
	  $fileFunction=fopen($phpFile,'r+')or die('Cannot open file:'.$phpFile);
	  while(!feof($fileFunction))
	  {
		  $displayFile=fgets($fileFunction);
		  echo $displayFile."<br>";
	  }
	  ?>