<!DOCTYPE html>
<html>
<head>
<title>file read</title>
</head>
<body>
<?php 
$phpFile='phpfile.txt';
$fileFunction=fopen($phpFile,'r')or die("Cannot open file:$phpfile");
echo "<h2>Here display file data character by character read only.</h2><br>";
while(!feof($fileFunction))
{
$displayFile=fgetc($fileFunction);
echo $displayFile."<br>";
}
?>