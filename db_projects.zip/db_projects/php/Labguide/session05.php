<!DOCTYPE html>
<html>
<title>Data type</title>
<head>
</head>
<body>
<?php
$integer=22222;
echo $integer;
?>
</body>
</html>