<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Insert</title>
</head>

<body>
	<?php 
          require("connect.php");
	      $createTable=mysqli_query($conn,"insert into student(first_name,last_name,age,phone_num) value('Hunaina','Shaik',35,1234567)")or die("Unable inserted Data");
	      if($createTable)
		  {
			  echo "Successfully Inserted Data";
		  }
	?>
</body>
</html>