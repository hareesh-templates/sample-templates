<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Array</title>
</head>

<body>
	<?php 
	$null=null;
	if(!isset($null))
	{
		echo "Variable not set";
	}
	else
	{
		echo "Variable set the value";
	}
	?>
</body>
</html>