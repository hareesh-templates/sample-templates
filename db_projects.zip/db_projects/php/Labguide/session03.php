<!DOCTYPE html>
<html>
<title>Single line comment</title>
<head>
</head>
<body>
<?php
$name="Hunaina";
echo $name;
?>
</body>
</html>