<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
	<?php
	$birthDate=date("08-06-1986");
	$dateToSec=Strtotime($birthDate);
	echo "Totla Seconds : ".$dateToSec."<br>";
	echo "Change Date Formate : ".date("l dS F Y",$dateToSec);
	?>
</body>
</html>