<!DOCTYPE html>
<html>
<title>Data type</title>
<head>
</head>
<body>
<?php
$stringName=" Hunaina Welcome to php world";
echo $stringName;
?>
</body>
</html>