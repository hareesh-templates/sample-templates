<!doctype html>
<html>
	<title>Error</title>
<head>
<meta charset="utf-8">
<title>Array</title>
</head>

<body>
	<?php 
	$name="Syntax error";
		echo $Name;
	$name="Notice error";
	    echo $Name;
	include("header.php");
	?>
</body>
</html>