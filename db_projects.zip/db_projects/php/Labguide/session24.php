<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
	<?php
	 $class=array("student1","student2","student3","student4");
	 $countArray=count($class);
	 print_r($class);
	 echo "<br><br>";
	 $i="";
	 for($i=0;$i<=$countArray;$i++)
	 {
		 echo $class[$i]."<br>";
		 	 }
	echo "<br><br>";
	echo "Method3<br><br>";
	echo $class[0]."<br>";
	echo $class[1]."<br>";
	echo $class[2]."<br>";
	echo $class[3]."<br>";
	 ?>
</body>
</html>