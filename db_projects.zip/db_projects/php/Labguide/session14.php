<!DOCTYPE html>
<html>
<title>comparison operator</title>
<head>
</head>
<body>
<?php

$marks1=30;
$marks2=50;

if($marks1==$marks2)
{
echo "Marks1 and Marks2 are equal <br>";
}
if($marks1!=$marks2)
{
echo "Marks1 and Marks2 are not equal <br>";
}
if($marks1>$marks2)
{
echo "Marks1 greater than Marks2<br>";
}
if($marks1>=$marks2)
{
echo "Marks1 greater than or equal to Marks2<br>";
}
if($marks1<=$marks2)
{
echo "Marks1 lessthan or equal to Marks2<br>";
}
if($marks1<$marks2)
{
echo "Marks1 lessthan Marks2<br>";
}
else
{
echo "Marks1 not less than or equal to Marks2<br>";
}
if($marks1===$marks2)
{
echo "Marks1 identical equal to Marks2";
}
else
{
echo "Marks1 not identical equal to Marks2";
}
?>
