<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
	<form method="POST" type="text" action="form.php">
		<h3>Contact Form</h3>
			 
		NAME:<input type="text" name="name"><br>
			  
			EMAIL:<input type="email" name="email" ><br>
		
			NUMBER:<input type="phone" name="number"><br>
			
			  Message:<input type="text" name="message"><br>
			  
			 <select name="select">
  
				 <option value="per">personal</option>
                                                             <option value="pub">public</option>
                                                              <option value="pri">private</option>
  
</select>
				   <input type="submit" name="submit" value="submit">  
				
				  </form>

</body>
</html>