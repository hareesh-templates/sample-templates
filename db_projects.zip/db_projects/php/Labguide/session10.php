<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Array</title>
</head>

<body>
	<?php 
	class Student{
		function Student()
		{
			$this->student_name="Hunaina";
		}
	}
	$objectName=new Student();
	echo $objectName->student_name;
	?>
</body>
</html>