<?php
     require("connect.php");
     $studeDetails=mysqli_query($conn,"select * from student");
?>