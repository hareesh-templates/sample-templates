<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>selectdata</title>
</head>

<body>
	<?php
     require("connect.php");
     $studeDetails=mysqli_query($conn,"select * from student");
?>
	<h1>Student Data in table format</h1>
	<table border="2px" style="border-collapse: collapse;width:900px" style="">
	<tr style="width:900px">
		<th>Sno</th>
		<th>Firstname</th>
		<th>Lastname</th>
		<th>Age</th>
		<th>Phone Number</th><th>actions</th>
		</tr>
		<?php $x="0";while($result=mysqli_fetch_array($studeDetails)){$x++;?>
		<tr>
			<td><?php echo $x;?></td>
			<td><?php echo $result['first_name']?></td>
			<td><?php echo $result['last_name']?></td>
			<td><?php echo $result['age']?></td>
			<td><?php echo $result['phone_num']?></td>
			<td><a href="delete1.php?id=<?php echo $result['std_id'];?>">Delete</a>/
				<a href="edit.php?id=<?php echo $result['std_id'];?>">Edit</a></td>
		</tr>
		<?php }?>
	</table>
</body>
</html>