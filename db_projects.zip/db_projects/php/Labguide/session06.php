<!DOCTYPE html>
<html>
<title>Data type</title>
<head>
</head>
<body>
<?php
$floatVar=89999.88;
echo $floatVar;
?>
</body>
</html>