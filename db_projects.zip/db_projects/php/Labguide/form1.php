<?php require("connect.php");
      if($_POST['submit_form'])
	  {
		  $firstname=$_POST['firstname'];
		  $lastname=$_POST['lastname'];
		  $email=$_POST['email'];
		  $phonenumber=$_POST['phone_number'];
		  $age=$_POST['age'];
		  
		  $createTable=mysqli_query($conn,"insert into student(first_name,last_name,phone_num,age) values('.$firstname.','.$lastname.','.$phonenumber.','.$age.')")or die("Unable to insert Data");
		  if($createTable)
		  {
			  echo "Successfully Created Table";
		  }
	  }
?>