<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Email</title>
</head>

<body>
	<?php
	     $to="to@gmail.com";
	     $subject="Subject Here";
	     $message="<b>We are sending mail using Php Email.</b>";
	     $header="From:from@domain.com\r\n";
	     $header.="Cc:cc@domain.com\r\n";
	     $header.="Bcc:bcc@domain.com\r\n";
	     $header.="MIME-Version: 1.0\r\n";
		 $header.="Content-type:text/html\r\n";
	     $emailSend=mail($to,$subject,$message,$header);
	     if($emailSend)
		 {
			 echo "Email sent successfully";
			 }
	      else
		  {
			echo "Email could not be sent";  
		  }
	?>
	</body>
</html>