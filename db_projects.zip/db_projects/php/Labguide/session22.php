<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
	<?php
	 $classRooms=20;
	 $students="0";
	 while($students<=$classRooms)
	 {
		 echo "The Student Number is :".$students."<br>";
		 $students++;
	 }
	
	 
	?>
</body>
</html>