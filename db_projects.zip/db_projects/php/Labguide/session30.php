<!doctype html>
<html>
<head>
<title>cookie</title>
</head>
<body>
<?php
          $cookieValue="Hunaina";
          setcookie("student_name",$cookieValue,time()+(10*365*24*60*60));
   if('setcookie')
{
echo "Successfully Cookie Set";
}      
?></body>
</html>