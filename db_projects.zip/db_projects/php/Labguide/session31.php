<!doctype html>
<html>
<head>
<title>cookiename</title>
</head>
<body>
<?php
          $cookieName="Hunaina";
          setcookie("student_name",$cookieName,time()+(10*365*24*60*60));
  if('setcookie')
{
echo "Successfully Cookie Set";
}
?>
</body>
</html>