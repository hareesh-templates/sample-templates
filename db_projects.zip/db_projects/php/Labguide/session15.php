<!DOCTYPE html>
<html>
<title>Logical Operators</title>
<head>
</head>
<?php 
$userName="abc";
$password="abc@123";
if($userName=="abc" && $password=="abc@123")
{
echo "And Logical Operator:User Successfully Loged in!"."<br>";
}
$userPhone="123456789";
if($useName="abc" || $userPhone="123456789" && $password=="abc@123")
{
echo "Or Logical Operator:User Successfully Loged in"."<br>";
}
if($userName!="abcd")
{
echo "Not Operator User Name is not:abc"."<br>";
}
?>