<html>
<head>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>




	<style>
		.emp_form .form-control {
			margin: 20px;
		}

	</style>
</head>
<div class="container">
	<div class="row">
		<div class="col-sm-6 offset-3 emp_form">
			<form action="insert.php" method="post">
				
				<input type="text" name="name" class="form-control" placeholder="Name">
				<input type="text" name="age" class="form-control" placeholder="Age">
				<input type="email" name="email" class="form-control" placeholder="Email">
				<input type="text" name="phone" class="form-control" placeholder="Phone number">
				<input type="submit" name="submit" class="form-control">
			</form>
		</div>
	</div>
</div>


</html>