<?php 
require("connect.php");



	$name = $_POST['name'];
	$age = $_POST['age'];
	$email = $_POST['email'];
	$pn = $_POST['phone'];
	

$query = "insert into employee (name,age,email,phone_number)
values('". $name ."', '".$age."', '".$email."', '".$pn."')";


$Table = mysqli_query($conn, $query);


if($Table){
	echo  "sucessfully created " ;
}
else{
	echo "not created";
}


?>
